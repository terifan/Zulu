package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPModel
{
	BoundingBox mBounds;
	Vector mOrigin; // for sounds or lights
	int mFaceIndex;
	int mNumFaces;
	int mHeadNode;


	public BSPModel(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		Vector min = new Vector();
		Vector max = new Vector();
		mOrigin = new Vector();

		min.x = aByteBuffer.getFloat();
		min.z = aByteBuffer.getFloat();
		min.y = aByteBuffer.getFloat();
		max.x = aByteBuffer.getFloat();
		max.z = aByteBuffer.getFloat();
		max.y = aByteBuffer.getFloat();
		mOrigin.x = aByteBuffer.getFloat();
		mOrigin.z = aByteBuffer.getFloat();
		mOrigin.y = aByteBuffer.getFloat();
		mHeadNode = aByteBuffer.getInt();
		mFaceIndex = aByteBuffer.getInt();
		mNumFaces = aByteBuffer.getInt();

		mBounds = new BoundingBox(min,max);
	}


	public static BSPModel [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 48 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 48;

		System.out.println("Loading BSPModel ("+count+" items)");

		BSPModel [] elements = new BSPModel[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPModel(aByteBuffer, aLump);
		}

		return elements;
	}
}
