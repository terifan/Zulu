package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPDispVert
{
//	Vector3f mDirection;
//	float mDisplacementDistance;
//	float mAlpha;
	Vector3f [] mDirections;
	float [] mDistances;
	float [] mAlphas;

	private BSPDispVert(ByteBuffer aByteBuffer, int aCount) throws IOException
	{
		mDirections = new Vector3f[aCount];
		mDistances = new float[aCount];
		mAlphas = new float[aCount];

		for (int i = 0; i < aCount; i++)
		{
			mDirections[i] = new Vector3f();
			mDirections[i].x = aByteBuffer.getFloat();
			mDirections[i].z = aByteBuffer.getFloat();
			mDirections[i].y = aByteBuffer.getFloat();
			mDistances[i] = aByteBuffer.getFloat();
			mAlphas[i] = Math.max(Math.min(aByteBuffer.getFloat() / 255f, 1), 0);
		}

/*		mDirection = new Vector3f();

		mDirection.x = aByteBuffer.getFloat();
		mDirection.z = aByteBuffer.getFloat();
		mDirection.y = aByteBuffer.getFloat();
		mDisplacementDistance = aByteBuffer.getFloat();
		mAlpha = aByteBuffer.getFloat();
		//mAlpha = Math.max(Math.min(aByteBuffer.getFloat() / 255f, 1), 0);
*/
	}

	public static BSPDispVert load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 20 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 20;

		System.out.println("Loading BSPDispVert ("+count+" items)");

		return new BSPDispVert(aByteBuffer, count);
/*
		BSPDispVert [] elements = new BSPDispVert[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPDispVert(aByteBuffer);
		}

		return elements;
*/
	}
}
