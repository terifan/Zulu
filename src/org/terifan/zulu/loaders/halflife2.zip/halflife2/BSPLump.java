package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPLump
{
    int mOffset;
    int mLength;
    int mVersion;
    int mFourCC;

	public BSPLump(ByteBuffer aByteBuffer) throws IOException
	{
		mOffset = aByteBuffer.getInt();
		mLength = aByteBuffer.getInt();
		mVersion = aByteBuffer.getInt();
		mFourCC = aByteBuffer.getInt();
	}
}