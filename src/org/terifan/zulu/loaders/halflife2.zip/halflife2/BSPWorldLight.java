package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPWorldLight
{
	Vector   origin;
	Vector   intensity;
	Vector   normal;   // for surfaces and spotlights
	int      cluster;
	EmitType type;
    int      style;
	double   stopdot;  // start of penumbra for emit_spotlight
	double   stopdot2; // end of penumbra for emit_spotlight
	double   exponent;
	double   radius;   // cutoff distance
	                   // falloff for emit_spotlight + emit_point: 
	                   // 1 / (constant_attn + linear_attn * dist + quadratic_attn * dist^2)
	double   constant_attn;	
	double   linear_attn;
	double   quadratic_attn;
	int      flags;
	int      texinfo;
	int      owner;    // entity that this light it relative to


	enum EmitType
	{
		SURFACE,    // 90 degree spotlight
		POINT,      // simple point light source
		SPOTLIGHT,  // spotlight with penumbra
		SKYLIGHT,   // directional light with no falloff (surface must trace to SKY texture)
		QUAKELIGHT, // linear falloff, non-lambertian
		SKYAMBIENT, // spherical light source with no falloff (surface must trace to SKY texture)
	};


	public BSPWorldLight(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		origin = new Vector();
		intensity = new Vector();
		normal = new Vector();

		origin.x = aByteBuffer.getFloat();
		origin.z = aByteBuffer.getFloat();
		origin.y = aByteBuffer.getFloat();
		intensity.x = aByteBuffer.getFloat();
		intensity.z = aByteBuffer.getFloat();
		intensity.y = aByteBuffer.getFloat();
		normal.x = aByteBuffer.getFloat();
		normal.z = aByteBuffer.getFloat();
		normal.y = aByteBuffer.getFloat();
		cluster = aByteBuffer.getInt();
		int t = aByteBuffer.getInt();
		style = aByteBuffer.getInt();
		stopdot = aByteBuffer.getFloat();
		stopdot2 = aByteBuffer.getFloat();
		exponent = aByteBuffer.getFloat();
		radius = aByteBuffer.getFloat();
		constant_attn = aByteBuffer.getFloat();
		linear_attn = aByteBuffer.getFloat();
		quadratic_attn = aByteBuffer.getFloat();
		flags = aByteBuffer.getInt();
		texinfo = aByteBuffer.getInt();
		owner = aByteBuffer.getInt();

		switch (t)
		{
			case 0:
				type = EmitType.SURFACE;
				break;
			case 1:
				type = EmitType.POINT;
				break;
			case 2:
				type = EmitType.SPOTLIGHT;
				break;
			case 3:
				type = EmitType.SKYLIGHT;
				break;
			case 4:
				type = EmitType.QUAKELIGHT;
				break;
			case 5:
				type = EmitType.SKYAMBIENT;
				break;
			default:
				throw new IOException("Bad WorldLight type: " + t);
		}

		if (type == EmitType.SPOTLIGHT)
		{
			if (constant_attn == 0.0 && linear_attn == 0.0 && quadratic_attn == 0.0)
			{
				quadratic_attn = 1.0;
			}

			if (exponent == 0.0)
			{
				exponent = 1.0;
			}
		}
		else if (type == EmitType.POINT)
		{
			// To match earlier lighting, use quadratic...
			if (constant_attn == 0.0 && linear_attn == 0.0 && quadratic_attn == 0.0)
			{
				quadratic_attn = 1.0;
			}
		}

   		// I replaced the cuttoff_dot field (which took a value from 0 to 1)
		// with a max light radius. Radius of less than 1 will never happen,
		// so I can get away with this. When I set radius to 0, it'll 
		// run the old code which computed a radius
		if (radius < 1)
		{
			radius = 0;
		}
	}


	public static BSPWorldLight [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 88 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 88;

		System.out.println("Loading BSPWorldLight ("+count+" items)");

		BSPWorldLight [] elements = new BSPWorldLight[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPWorldLight(aByteBuffer, aLump);
		}

		return elements;
	}

/*

float Engine_WorldLightDistanceFalloff( const dworldlight_t *wl, const Vector& delta, bool bNoRadiusCheck )
{
	float falloff;

	switch (wl->type)
	{
		case emit_surface:
#if 1
			// Cull out stuff that's too far
			if (wl->radius != 0)
			{
				if ( DotProduct( delta, delta ) > (wl->radius * wl->radius))
					return 0.0f;
			}

			return InvRSquared(delta);
#else
			// 1/r*r
			falloff = DotProduct( delta, delta );
			if (falloff < 1)
				return 1.f;
			else
				return 1.f / falloff;
#endif

			break;

		case emit_skylight:
			return 1.f;
			break;

		case emit_quakelight:
			// X - r;
			falloff = wl->linear_attn - FastSqrt( DotProduct( delta, delta ) );
			if (falloff < 0)
				return 0.f;

			return falloff;
			break;

		case emit_skyambient:
			return 1.f;
			break;

		case emit_point:
		case emit_spotlight:	// directional & positional
			{
				float dist2, dist;

				dist2 = DotProduct( delta, delta );
				dist = FastSqrt( dist2 );

				// Cull out stuff that's too far
				if (!bNoRadiusCheck && (wl->radius != 0) && (dist > wl->radius))
					return 0.f;

				return 1.f / (wl->constant_attn + wl->linear_attn * dist + wl->quadratic_attn * dist2);
			}

			break;
		default:
			// Bug: need to return an error
			break;
	}
	return 1.f;
}








float Engine_WorldLightAngle( const dworldlight_t *wl, const Vector& lnormal, const Vector& snormal, const Vector& delta )
{
	float dot, dot2, ratio = 0;

	switch (wl->type)
	{
		case emit_surface:
			dot = DotProduct( snormal, delta );
			if (dot < 0)
				return 0;

			dot2 = -DotProduct (delta, lnormal);
			if (dot2 <= ON_EPSILON/10)
				return 0; // behind light surface

			return dot * dot2;

		case emit_point:
			dot = DotProduct( snormal, delta );
			if (dot < 0)
				return 0;
			return dot;

		case emit_spotlight:
			dot = DotProduct( snormal, delta );
			if (dot < 0)
				return 0;

			dot2 = -DotProduct (delta, lnormal);
			if (dot2 <= wl->stopdot2)
				return 0; // outside light cone

			ratio = dot;
			if (dot2 >= wl->stopdot)
				return ratio;	// inside inner cone

			if ((wl->exponent == 1) || (wl->exponent == 0))
			{
				ratio *= (dot2 - wl->stopdot2) / (wl->stopdot - wl->stopdot2);
			}
			else
			{
				ratio *= pow((dot2 - wl->stopdot2) / (wl->stopdot - wl->stopdot2), wl->exponent );
			}
			return ratio;

		case emit_skylight:
			dot2 = -DotProduct( snormal, lnormal );
			if (dot2 < 0)
				return 0;
			return dot2;

		case emit_quakelight:
			// linear falloff
			dot = DotProduct( snormal, delta );
			if (dot < 0)
				return 0;
			return dot;

		case emit_skyambient:
			// not supported
			return 1;

		default:
			// Bug: need to return an error
			break;
	} 
	return 0;
}

*/
}