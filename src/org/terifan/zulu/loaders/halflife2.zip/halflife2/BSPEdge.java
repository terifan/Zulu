package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPEdge
{
	int [] mVertexIndices;

	private BSPEdge(ByteBuffer aByteBuffer) throws IOException
	{
		mVertexIndices = new int[2];
		mVertexIndices[0] = aByteBuffer.getUnsignedShort();
		mVertexIndices[1] = aByteBuffer.getUnsignedShort();
	}

	public static BSPEdge [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 4 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 4;

		System.out.println("Loading BSPEdge ("+count+" items)");

		BSPEdge [] elements = new BSPEdge[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPEdge(aByteBuffer);
		}

		return elements;
	}
}
