package org.terifan.zeus.io.halflife2;

import java.util.HashMap;
import java.util.ArrayList;
import java.io.*;
import org.terifan.io.ByteBuffer;


class BSPEntities
{
	ArrayList<HashMap<String,String>> mEntites = new ArrayList<HashMap<String,String>>();

	private BSPEntities(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		aByteBuffer.position(aLump.mOffset);

		LineNumberReader reader = new LineNumberReader(new StringReader(aByteBuffer.getString(aLump.mLength,true,false)));

		HashMap<String,String> map = null;

		for (String s; (s = reader.readLine()) != null;)
		{
			if (s.equals("{"))
			{
				map = new HashMap<String,String>();
				mEntites.add(map);
			}
			else if (s.equals("}"))
			{
			}
			else
			{
				String [] t = s.substring(1, s.length()-1).split("\" \"");
				if (t.length == 1)
				{
					map.put(t[0].toLowerCase(), "");
				}
				else
				{
					map.put(t[0].toLowerCase(), t[1]);
					
					//System.out.println(t[0].toLowerCase()+"="+t[1]);
				}
			}
		}
	}

	public static BSPEntities load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPEntities (1 items)");

		return new BSPEntities(aByteBuffer, aLump);
	}


	public ArrayList<HashMap<String,String>> getEntityByName(String aClassName)
	{
		ArrayList<HashMap<String,String>> result = new ArrayList<HashMap<String,String>>();

		for (int i = 0; i < mEntites.size(); i++)
		{
			HashMap<String,String> entity = mEntites.get(i);
			if (entity.get("classname").equalsIgnoreCase(aClassName))
			{
				result.add(entity);
			}
		}

		return result;
	}
}