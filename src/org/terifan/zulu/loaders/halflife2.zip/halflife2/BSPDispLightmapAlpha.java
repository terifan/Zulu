package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPDispLightmapAlpha
{
	public static byte [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPDispLightmapAlpha (1 items)");

		BSPDispLightmapAlpha lump = new BSPDispLightmapAlpha();

		byte [] alphas = new byte[aLump.mLength];

		aByteBuffer.get(alphas);

		return alphas;
	}
}