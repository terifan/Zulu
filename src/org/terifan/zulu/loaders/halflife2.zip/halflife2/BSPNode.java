package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPNode
{
	int mIndex;
	int mPlaneIndex;
	int [] mChildIndices; // negative numbers are -(leafs+1), not nodes
	int mFaceIndex;
	int mNumFaces;        // counting both sides
	int mArea;            // If all leaves below this node are in the same area, then this is the area index. If not, this is -1.
	BoundingBox mBounds;  // for frustom culling


	private BSPNode(ByteBuffer aByteBuffer) throws IOException
	{
		mBounds = new BoundingBox();
		mChildIndices = new int[2];

		mPlaneIndex = aByteBuffer.getInt();
		mChildIndices[0] = aByteBuffer.getInt();
		mChildIndices[1] = aByteBuffer.getInt();
		Vector v = new Vector();
		v.x = aByteBuffer.getShort();
		v.z = aByteBuffer.getShort();
		v.y = aByteBuffer.getShort();
		mBounds.merge(v);
		v.x = aByteBuffer.getShort();
		v.z = aByteBuffer.getShort();
		v.y = aByteBuffer.getShort();
		mBounds.merge(v);
		mFaceIndex = aByteBuffer.getUnsignedShort();
		mNumFaces = aByteBuffer.getUnsignedShort();
		mArea = aByteBuffer.getShort();
		aByteBuffer.skip(2);
	}

	public static BSPNode [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 32 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 32;

		System.out.println("Loading BSPNode ("+count+" items)");

		BSPNode [] elements = new BSPNode[count];

		for (int index = 0; index < count; index++)
		{

			elements[index] = new BSPNode(aByteBuffer);

			elements[index].mIndex = index;
		}

		return elements;
	}
}
