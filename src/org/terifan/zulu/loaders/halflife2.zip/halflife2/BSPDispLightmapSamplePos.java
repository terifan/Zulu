package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPDispLightmapSamplePos
{
	int [] triangleIndex = new int[100];
	int [] coordinate = new int[100];

	private BSPDispLightmapSamplePos(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPDispLightmapSamplePos (1 items)");

		aByteBuffer.position(aLump.mOffset);

		int size = 0;

		for (int i = 0; i < aLump.mLength; i+=4)
		{
			int j = aByteBuffer.getUnsignedByte();
			if (j == 255)
			{
				j += aByteBuffer.getUnsignedByte();
				i++;
			}

			if (size >= triangleIndex.length)
			{
				int [] temp = new int[size * 3 / 2];
				System.arraycopy(triangleIndex, 0, temp, 0, triangleIndex.length);
				triangleIndex = temp;

				temp = new int[size * 3 / 2];
				System.arraycopy(coordinate, 0, temp, 0, coordinate.length);
				coordinate = temp;
			}

			triangleIndex[size] = j;
			coordinate[size] = (aByteBuffer.getUnsignedByte()<<16) + (aByteBuffer.getUnsignedByte()<<8) + aByteBuffer.getUnsignedByte();
			size++;
		}

		int [] temp = new int[size];
		System.arraycopy(triangleIndex, 0, temp, 0, size);
		triangleIndex = temp;

		temp = new int[size];
		System.arraycopy(coordinate, 0, temp, 0, size);
		coordinate = temp;
	}

	public static BSPDispLightmapSamplePos load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		return new BSPDispLightmapSamplePos(aByteBuffer, aLump);
	}
}
