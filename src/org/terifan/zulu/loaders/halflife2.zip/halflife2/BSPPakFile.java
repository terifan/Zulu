package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.zip.*;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPPakFile
{
	HashMap<String,Texture> mTextures;
	HashMap<String,String> mScripts;

	private BSPPakFile(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		byte [] buffer = new byte[aLump.mLength];
		aByteBuffer.position(aLump.mOffset);
		aByteBuffer.get(buffer);

		mTextures = new HashMap<String,Texture>();
		mScripts = new HashMap<String,String>();

		ZipInputStream zipInputStream = new ZipInputStream(new ByteArrayInputStream(buffer));
		for (;;)
		{
			ZipEntry entry = zipInputStream.getNextEntry();

			if (entry == null)
			{
				break;
			}

			if (entry.getName().toLowerCase().endsWith(".vtf"))
			{
				try
				{
					Texture tex = Texture.read(entry.getName(), zipInputStream, true);
					tex.generateMipMaps(true);
					mTextures.put(entry.getName(), tex);
				}
				catch (IOException e)
				{
//					e.printStackTrace();
					mTextures.put(entry.getName(), new Texture(1,1,new int[]{0xFF0000}));
				}
			}
			else if (entry.getName().toLowerCase().endsWith(".vmt"))
			{
				byte [] buf = new byte[(int)entry.getSize()];
				zipInputStream.read(buf);
				mScripts.put(entry.getName(), new String(buf));
			}
			else
			{
				throw new IOException(entry.getName());
			}

			zipInputStream.closeEntry();
		}
		zipInputStream.close();
	}

	public static BSPPakFile load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPPakFile (1 items)");

		return new BSPPakFile(aByteBuffer, aLump);
	}
}
