package org.terifan.zeus.io.halflife2;


class RGBExp
{
	int r, g, b, exponent;
}