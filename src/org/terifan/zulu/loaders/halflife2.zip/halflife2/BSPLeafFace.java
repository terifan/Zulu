package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPLeafFace
{
	int [] mIndices;

	private BSPLeafFace() throws IOException
	{
	}

	public static BSPLeafFace load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 2 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 2;

		System.out.println("Loading BSPLeafFace ("+count+" items)");

		BSPLeafFace leafFace = new BSPLeafFace();
		leafFace.mIndices = new int[count];

		for (int index = 0; index < count; index++)
		{
			leafFace.mIndices[index] = aByteBuffer.getUnsignedShort();
		}

		return leafFace;
	}
}