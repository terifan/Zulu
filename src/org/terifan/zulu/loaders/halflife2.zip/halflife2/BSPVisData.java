package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;
import org.terifan.zeus.scenegraph.*;


class BSPVisData
{
	BSPPotentiallyVisibleSet mPVS;


	private BSPVisData()
	{
	}

	public static BSPVisData load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		aByteBuffer.position(aLump.mOffset);

		int numClusters = aByteBuffer.getInt();

		System.out.println("Loading BSPVisData ("+numClusters+" items)");

		int [] offsets = new int[numClusters];

		for (int i = 0; i < numClusters; i++)
		{
			offsets[i] = aLump.mOffset + aByteBuffer.getInt();
			aByteBuffer.skip(4);
		}

		byte [][] visBits = new byte[numClusters][numClusters / 8 + 1];

		for (int i = 0; i < numClusters; i++)
		{
			byte [] bits = visBits[i];

			aByteBuffer.position(offsets[i]);

			for (int j = 0; j < numClusters/8;)
			{
				byte b = aByteBuffer.get();

				if (b == 0)
				{
					int k = aByteBuffer.getUnsignedByte();
					j += k;
				}
				else
				{
					bits[j++] = b;
				}
			}
		}

		BSPVisData visData = new BSPVisData();
		visData.mPVS = new BSPPotentiallyVisibleSet(numClusters, visBits);

		return visData;
	}


	static class BSPPotentiallyVisibleSet implements PotentiallyVisibleSet
	{
		private int mNumClusters;
		private byte [][] mVisBits;
		private int mSourceId = Integer.MIN_VALUE;


		public BSPPotentiallyVisibleSet(int aNumClusters, byte [][] aVisBits)
		{
			mNumClusters = aNumClusters;
			mVisBits = aVisBits;
		}


		public int updateView(BranchGroup aBranchGroup, Transform3D aTransform)
		{
			Node node = aBranchGroup;
			Vector viewVector = aTransform.getPosition();

			for (int i = 0, sz = aBranchGroup.getChildCount(); i < sz; i++)
			{
				node = aBranchGroup.getChild(i).getIdentityNodeForPoint(viewVector, node);
			}

			if (node == null)
			{
				return RENDER_ALL;
			}

			int prev = mSourceId;

			Identity i = node.getIdentity();

			if (i == null) 
			{
				mSourceId = -1;
			}
			else if (i instanceof MultiIdentity)
			{
				for (;;)
				{
					node = node.getParent();

					if (node == null)
					{
						return RENDER_ALL;
					}
					if (node.getIdentity() instanceof NodeIdentity)
					{
						mSourceId = ((NodeIdentity)i).getID();
						return prev == mSourceId ? UNCHANGED_STATE : QUERY_STATE;
					}
				}
			}
			else
			{
				mSourceId = ((NodeIdentity)i).getID();
			}

			return prev == mSourceId ? UNCHANGED_STATE : QUERY_STATE;
		}


		public boolean isVisible(Node aTarget)
		{
			if (mSourceId == -1 || mSourceId >= mNumClusters)
			{
				return true;
			}

			Identity id = aTarget.getIdentity();
			
			if (id instanceof NodeIdentity)
			{
				int targetId = ((NodeIdentity)aTarget.getIdentity()).getID();
	
				if (mSourceId == targetId || targetId < 0 || targetId >= mNumClusters)
				{
					return true;
				}
	
				return (mVisBits[mSourceId][targetId / 8] & (1 << (targetId & 7))) != 0;
			}
			else
			{
				int [] ids = ((MultiIdentity)aTarget.getIdentity()).getIDs();

				for (int i = 0; i < ids.length; i++)
				{
					int targetId = ids[i];

					if (targetId >= 0 && targetId < mNumClusters && (mVisBits[mSourceId][targetId / 8] & (1 << (targetId & 7))) != 0)
					{
						return true;
					}
				}

				return false;
			}
		}
	}
}