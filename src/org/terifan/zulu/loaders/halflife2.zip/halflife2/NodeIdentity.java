package org.terifan.zeus.io.halflife2;

import org.terifan.zeus.scenegraph.*;


public class NodeIdentity implements Identity
{
	private int mID;


	public NodeIdentity(int aID)
	{
		mID = aID;
	}


	public int getID()
	{
		return mID;
	}


	@Override
	public String toString()
	{
		return ""+mID;
	}


	public boolean equals(Identity aIdentity)
	{
		return (aIdentity instanceof NodeIdentity) && ((NodeIdentity)aIdentity).mID == mID;
	}
}