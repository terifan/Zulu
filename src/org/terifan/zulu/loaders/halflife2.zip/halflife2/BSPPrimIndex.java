package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPPrimIndex
{
	int mIndex;

	private BSPPrimIndex(ByteBuffer aByteBuffer) throws IOException
	{
		mIndex = aByteBuffer.getUnsignedShort();
	}

	public static BSPPrimIndex [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 2 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 12;

		System.out.println("Loading BSPPrimIndex ("+count+" items)");

		BSPPrimIndex [] elements = new BSPPrimIndex[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPPrimIndex(aByteBuffer);
		}

		return elements;
	}
}
