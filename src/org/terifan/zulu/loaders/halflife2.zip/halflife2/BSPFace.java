package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPFace
{
	int mPlaneNum;
	int mSide;                             // faces opposite to the node's plane direction
	int mOnNode;                           // 1 of on node, 0 if in leaf
	int mFirstEdge;                        // we must support > 64k edges
	int mNumEdges;	
	int mTexInfo;
    int mDispInfo;
	int mSurfaceFogVolumeID;
	int [] mStyles;
	int mLightOffset;                      // start of [numstyles*surfsize] samples
    double mArea;
	int mLightmapTextureMinsInLuxelsU;
	int mLightmapTextureMinsInLuxelsV;
	int mLightmapTextureSizeInLuxelsU;
	int mLightmapTextureSizeInLuxelsV;
    int mOrigFace;                         // reference the original face this face was derived from
	int mNumPrims;
	int mFirstPrim; 
	long mSmoothingGroups;

	private BSPFace(ByteBuffer aByteBuffer) throws IOException
	{
		mStyles = new int[BSPLoader.MAXLIGHTMAPS];

		mPlaneNum = aByteBuffer.getUnsignedShort();
		mSide = aByteBuffer.get();
		mOnNode = aByteBuffer.get();
		mFirstEdge = aByteBuffer.getInt();
		mNumEdges = aByteBuffer.getShort();
		mTexInfo = aByteBuffer.getShort();
	    mDispInfo = aByteBuffer.getShort();
		mSurfaceFogVolumeID = aByteBuffer.getShort();
		for (int i = 0; i < BSPLoader.MAXLIGHTMAPS; i++)
		{
			mStyles[i] = aByteBuffer.get();
		}
		mLightOffset = aByteBuffer.getInt();
	    mArea = aByteBuffer.getFloat();
		mLightmapTextureMinsInLuxelsU = aByteBuffer.getInt();
		mLightmapTextureMinsInLuxelsV = aByteBuffer.getInt();
		mLightmapTextureSizeInLuxelsU = aByteBuffer.getInt();
		mLightmapTextureSizeInLuxelsV = aByteBuffer.getInt();
	    mOrigFace = aByteBuffer.getInt();
		mNumPrims = aByteBuffer.getUnsignedShort();
		mFirstPrim = aByteBuffer.getUnsignedShort();
		mSmoothingGroups = aByteBuffer.getUnsignedInt();
	}


	public static BSPFace [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % (52 + BSPLoader.MAXLIGHTMAPS) != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / (52 + BSPLoader.MAXLIGHTMAPS);

		System.out.println("Loading BSPFace ("+count+" items)");

		BSPFace [] elements = new BSPFace[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPFace(aByteBuffer);
		}

		return elements;
	}
}