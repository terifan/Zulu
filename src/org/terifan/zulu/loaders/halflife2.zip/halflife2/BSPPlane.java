package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPPlane
{
	Plane mPlane;
	int mType;

	public BSPPlane(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		double x = aByteBuffer.getFloat();
		double z = aByteBuffer.getFloat();
		double y = aByteBuffer.getFloat();
		double d = aByteBuffer.getFloat();
		mType = aByteBuffer.getInt();

		mPlane = new Plane(new Vector(x, y, z), d);
	}

	public static BSPPlane [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 20 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 20;

		System.out.println("Loading BSPPlane ("+count+" items)");

		BSPPlane [] elements = new BSPPlane[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPPlane(aByteBuffer, aLump);
		}

		return elements;
	}
}
