package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;
import org.terifan.zeus.util.*;


class BSPLighting
{
	private static double [] mLinearToVertex = new double[4096];
	byte [] mData;

	static
	{
		double overbright = 2;
		double screenGamma = 2.0;

		double overbrightFactor;

		if ( overbright == 2.0 )
		{
			overbrightFactor = 0.5;
		}
		else if ( overbright == 4.0 )
		{
			overbrightFactor = 0.25;
		}
		else
		{
			overbrightFactor = 1.0;
		}

		for (int i=0 ; i<4096 ; i++)
		{
			double f = Math.pow(i / 1024.0, 1.0 / screenGamma);

			mLinearToVertex[i] = f * overbrightFactor;

			if (mLinearToVertex[i] > 1)
			{
				mLinearToVertex[i] = 1;
			}
		}
	}


	public BSPLighting(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		mData = new byte[aLump.mLength];
		aByteBuffer.position(aLump.mOffset);
		aByteBuffer.get(mData);
	}


	private static double texLightToLinear(int c, int exponent)
	{
		return c * Math.pow(2, exponent) * (1.0 / 255.0);
	}


	private static void linearToLightmap(byte [] aSrcRGBE, int aOffset, int [] aDstRGB)
	{
		double [] tmpVect = new double[3];

		for(int j = 0; j < 3; j++ )
		{
			double c = texLightToLinear(aSrcRGBE[aOffset + j] & 255, (int)aSrcRGBE[aOffset + 3]);

			int i = (int)(c * 1024);
			if (i < 0)
			{
				i = 0;
			}
			else if (i > 4091)
			{
				i = 4091;
			}

			tmpVect[j] = mLinearToVertex[i];
		}

//		colorClamp(tmpVect);

		aDstRGB[0] = (int)(tmpVect[0] * 255.0);
		aDstRGB[1] = (int)(tmpVect[1] * 255.0);
		aDstRGB[2] = (int)(tmpVect[2] * 255.0);
	}


	private static void colorClamp(double [] color)
	{
		double max = Math.max(Math.max(color[0], color[1]), color[2]);

		if (max > 1.0)
		{
			max = 1.0 / max;
			color[0] *= max;
			color[1] *= max;
			color[2] *= max;
		}

		if (color[0] < 0) color[0] = 0;
		if (color[1] < 0) color[1] = 0;
		if (color[2] < 0) color[2] = 0;
	}


	public Texture getLightmap(int aOffset, int aWidth, int aHeight) throws IOException
	{
		int [] samples = new int[aWidth*aHeight];
		int [] dst = new int[3];

		for (int i = 0, j = aOffset; i < samples.length; i++, j+=4)
		{
			linearToLightmap(mData, j, dst);
			samples[i] = (dst[0]<<16) + (dst[1]<<8) + dst[2];
		}

		Texture tex = TextureTools.createTexture(aWidth, aHeight, samples);

		return tex;
	}


	public static BSPLighting load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPLighting (1 items)");

		return new BSPLighting(aByteBuffer, aLump);
	}




/*
void Vec3toColorRGBExp32( Vector& v, colorRGBExp32 *c )
{
	int i;		
	float max = 0.0f;				
	for( i = 0; i < 3; i++ )
	{
		// Get the maximum value.
		if( v[i] > max )
		{
			max = v[i];
		}
	}
				
	// figure out the exponent for this luxel.
	int exponent = CalcExponent( max );
				
	// make the exponent fits into a signed byte.
	if( exponent < -128 )
	{
		exponent = -128;
	}
	else if( exponent > 127 )
	{
		exponent = 127;
	}
				
	// undone: optimize with a table
	float scalar = pow( 2.0f, -exponent );
	// convert to mantissa x 2^exponent format
	for( i = 0; i < 3; i++ )
	{
		v[i] *= scalar;
		// clamp
		if( v[i] > 255.0f )
		{
			v[i] = 255.0f;
		}
	}
	c->r = ( unsigned char )v[0];
	c->g = ( unsigned char )v[1];
	c->b = ( unsigned char )v[2];
	c->exponent = ( signed char )exponent;
}
*/
}