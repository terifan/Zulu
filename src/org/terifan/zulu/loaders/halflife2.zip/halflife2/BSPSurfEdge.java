package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPSurfEdge
{
	int mIndex;

	private BSPSurfEdge(ByteBuffer aByteBuffer) throws IOException
	{
		mIndex = aByteBuffer.getInt();
	}

	public static BSPSurfEdge [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 4 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 4;

		System.out.println("Loading BSPSurfEdge ("+count+" items)");

		BSPSurfEdge [] elements = new BSPSurfEdge[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPSurfEdge(aByteBuffer);
		}

		return elements;
	}
}
