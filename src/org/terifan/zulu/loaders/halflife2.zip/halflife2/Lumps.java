package org.terifan.zeus.io.halflife2;


enum Lumps
{
	ENTITIES(0),
	PLANES(1),
	TEXDATA(2),
	VERTEXES(3),
	VISIBILITY(4),
	NODES(5),
	TEXINFO(6),
	FACES(7),
	LIGHTING(8),
	OCCLUSION(9),
	LEAFS(10),
	// 11 unused
	EDGES(12),
	SURFEDGES(13),
	MODELS(14),
	WORLDLIGHTS(15),
	LEAFFACES(16),
	LEAFBRUSHES(17),
	BRUSHES(18),
	BRUSHSIDES(19),
	AREAS(20),
	AREAPORTALS(21),
	PORTALS(22),
	CLUSTERS(23),
	PORTALVERTS(24),
	CLUSTERPORTALS(25),
	DISPINFO(26),
	ORIGINALFACES(27),
	PHYSCOLLIDE(29),
	VERTNORMALS(30),
	VERTNORMALINDICES(31),
	DISP_LIGHTMAP_ALPHAS(32),
	DISP_VERTS(33),
	DISP_LIGHTMAP_SAMPLE_POSITIONS(34),
	GAMELUMP(35),
	LEAFWATERDATA(36),
	PRIMITIVES(37),
	PRIMVERTS(38),
	PRIMINDICES(39),

	// A pak file can be embedded in a .bsp now, and the file system will search the pak
	// file first for any referenced names, before deferring to the game directory 
	// file system/pak files and finally the base directory file system/pak files.
	PAKFILE(40),

	CLIPPORTALVERTS(41),

	// A map can have a number of cubemap entities in it which cause cubemap renders
	// to be taken after running vrad.
	CUBEMAPS(42),

	TEXDATA_STRING_DATA(43),
	TEXDATA_STRING_TABLE(44),
	OVERLAYS(45),
	LEAFMINDISTTOWATER(46),
	FACE_MACRO_TEXTURE_INFO(47),
	DISP_TRIS(48),

	PHYSCOLLIDESURFACE(49), // Physics collision surface data(?)
	
	// 50-52 unused
	
	LIGHTINGHDR(53), // HDR related lighting data(?)
	WORLDLIGHTSHDR(54), // HDR related worldlight data(?)
	LEAFLIGHTHDR1(55), // HDR related leaf lighting data(?)
	LEAFLIGHTHDR2(56); // HDR related leaf lighting data(?)

	// 57-63 unused

	public final int ordinal;
	private Lumps(int ordinal)
	{
		this.ordinal = ordinal;
	}
}