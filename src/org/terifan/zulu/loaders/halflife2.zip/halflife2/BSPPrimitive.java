package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPPrimitive
{
	int mType;
	int mFirstIndex;
	int mNumIndices;
	int mFirstVertex;
	int mNumVertices;

	private BSPPrimitive(ByteBuffer aByteBuffer) throws IOException
	{
		mType = aByteBuffer.getUnsignedShort();
		mFirstIndex = aByteBuffer.getUnsignedShort();
		mNumIndices = aByteBuffer.getUnsignedShort();
		mFirstVertex = aByteBuffer.getUnsignedShort();
		mNumVertices = aByteBuffer.getUnsignedShort();
	}

	public static BSPPrimitive [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 10 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 10;

		System.out.println("Loading BSPPrimitive ("+count+" items)");

		BSPPrimitive [] elements = new BSPPrimitive[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPPrimitive(aByteBuffer);
		}

		return elements;
	}
}
