package org.terifan.zeus.io.halflife2;

import org.terifan.zeus.scenegraph.*;


public class MultiIdentity implements Identity
{
	private int [] mIDs;


	public MultiIdentity(int [] aIDs)
	{
		mIDs = aIDs;
	}


	public int [] getIDs()
	{
		return mIDs;
	}


	@Override
	public String toString()
	{
		String s = "";

		for (int i = 0; i < mIDs.length; i++)
		{
			if (i > 0)
			{
				s += ", ";
			}
			s += mIDs[i];
		}

		return s;
	}


	public boolean equals(Identity aIdentity)
	{
		return (aIdentity instanceof MultiIdentity) && java.util.Arrays.equals(((MultiIdentity)aIdentity).mIDs, mIDs);
	}
}