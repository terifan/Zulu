package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPTexData
{
	Vector mReflectivity;
	int mNameID;
	int mWidth;
	int mHeight;
	int mViewWidth;
	int mViewHeight;

	private BSPTexData(ByteBuffer aByteBuffer) throws IOException
	{
		mReflectivity = new Vector();
	
		mReflectivity.x = aByteBuffer.getFloat();
		mReflectivity.z = aByteBuffer.getFloat();
		mReflectivity.y = aByteBuffer.getFloat();
		mNameID = aByteBuffer.getInt();
		mWidth = aByteBuffer.getInt();
		mHeight = aByteBuffer.getInt();
		mViewWidth = aByteBuffer.getInt();
		mViewHeight = aByteBuffer.getInt();
	}

	public static BSPTexData [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 32 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 32;

		System.out.println("Loading BSPTexData ("+count+" items)");

		BSPTexData [] elements = new BSPTexData[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPTexData(aByteBuffer);
		}

		return elements;
	}
}
