package org.terifan.zeus.io.halflife2;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import org.terifan.zeus.*;
import org.terifan.zeus.geometry.*;
import org.terifan.zeus.scenegraph.*;
import org.terifan.zeus.util.*;
import org.terifan.io.ByteBuffer;

/*

origin=840 1920 -8164
fogend=50000
fogstart=0
fogdir=1 0 0
fogcolor2=255 255 255
fogcolor=100 120 130
use_angles=0
fogblend=0
fogenable=1
scale=16
angles=0 0 0
classname=sky_camera


culla allt som �r bortom worldspawn.maxrange

skyboxen ritas i en egen process med en kamera som startar p� coordinaten sky_camera.origin

skala all grafik med sky_camera.scale



world_maxs=3934 5120 1094
world_mins=-2464 -2336 -80
maxpropscreenwidth=-1
maxrange=8000
skyname=tides
classname=worldspawn

*/

public class BSPLoader
{
	public final static boolean FILTER_TEXTURES = true;

	final static int MAXLIGHTMAPS = 4;

	final static int SURFDRAW_NOLIGHT        = 0x0001;            // no lightmap
	final static int SURFDRAW_NODE           = 0x0002;            // This surface is on a node
	final static int SURFDRAW_SKY            = 0x0004;            // portal to sky
	final static int SURFDRAW_BUMPLIGHT      = 0x0008;            // Has multiple lightmaps for bump-mapping
	final static int SURFDRAW_NODRAW         = 0x0010;            // don't draw this surface, not really visible
	final static int SURFDRAW_TRANS          = 0x0020;            // sort this surface from back to front
	final static int SURFDRAW_PLANEBACK      = 0x0040;            // faces away from plane of the node that stores this face
	final static int SURFDRAW_DYNAMIC        = 0x0080;            // Don't use a static buffer for this face
	final static int SURFDRAW_TANGENTSPACE   = 0x0100;            // This surface needs a tangent space
	final static int SURFDRAW_NOCULL         = 0x0200;            // Don't bother backface culling these
	final static int SURFDRAW_ABOVEWATER     = 0x0400;            // At least partially above water
	final static int SURFDRAW_UNDERWATER     = 0x0800;            // At least partially underwater
	final static int SURFDRAW_WATERSURFACE   = 0x1000;            // water surface
	final static int SURFDRAW_HASLIGHTSYTLES = 0x2000;            // has a lightstyle other than 0
	final static int SURFDRAW_HAS_DISP       = 0x4000;            // has a dispinfo

	SceneGraph mSceneGraph;

	BSPDispInfo [] mDispInfoLump;
	BSPDispLightmapSamplePos mDispLightmapPosLump;
	BSPDispTri [] mDispTriLump;
	BSPDispVert mDispVertLump;
	BSPEdge [] mEdgeLump;
	BSPEntities mEntityLump;
	BSPFace [] mFaceLump;
	BSPFace [] mOriginalFaceLump;
	BSPGameLump mGameLump;
	BSPLeaf [] mLeafLump;
	BSPLeafFace mLeafFaceLump;
	BSPLighting mLightingLump;
	BSPModel [] mModelLump;
	BSPNode [] mNodeLump;
	BSPPakFile mPakFileLump;
	BSPPlane [] mPlaneLump;
	BSPPrimIndex [] mPrimIndexLump;
	BSPPrimitive [] mPrimitiveLump;
	BSPPrimVert [] mPrimVertLump;
	BSPSurfEdge [] mSurfEdgeLump;
	BSPTexData [] mTexDataLump;
	BSPTexDataStrings mTexDataStringLump;
	BSPTexInfo [] mTexInfoLump;
	BSPVertex [] mVertexLump;
	BSPVisData mVisData;
	BSPWorldLight [] mWorldLights;
	byte [] mDispLightmapAlphaLump;

	private Texture mWhiteTexture;
	private ShaderLoader mShaderLoader;
	private ResourceFinder mResourceFinder;
	private HashMap<Integer,RenderingCondition> mRenderingConditions;


	public BSPLoader(ResourceFinder aResourceFinder, LoadProgressUpdater aProgressUpdater, String aMapName) throws IOException
	{
		mRenderingConditions = new HashMap<Integer,RenderingCondition>();
		mShaderLoader = new ShaderLoader();
		mResourceFinder = aResourceFinder;

		ByteBuffer in = ByteBuffer.createLittleEndian(mResourceFinder.find(aMapName));

		if (!in.getString(4,false,false).equals("VBSP"))
		{
			throw new IOException("Not an VBSP file: " + mResourceFinder.find(aMapName));
		}
		int version = in.getInt();
		if (version != 19 && version != 20)
		{
			throw new IOException("VBSP version not supported: " + version);
		}

		BSPLump [] lumps = new BSPLump[49];

		for (int i = 0; i < 49; i++)
		{
			lumps[i] = new BSPLump(in);
		}

		mEntityLump = BSPEntities.load(in, lumps[Lumps.ENTITIES.ordinal]); // 0

		ArrayList<HashMap<String,String>> fogEntity = mEntityLump.getEntityByName("env_fog_controller");
		if (fogEntity.size() > 0)
		{
			if (fogEntity.get(0).get("fogenable").equals("1"))
			{
				double fogEnd = Double.parseDouble(fogEntity.get(0).get("fogend"));
				double fogStart = Double.parseDouble(fogEntity.get(0).get("fogstart"));
				//fogEntity.get(0).get("fogdir")
				String [] fogColor = fogEntity.get(0).get("fogcolor").split(" ");
				//fogEntity.get(0).get("fogcolor2")
				//fogEntity.get(0).get("fogblend")

				Color color = new Color(Double.parseDouble(fogColor[0])/255.0, Double.parseDouble(fogColor[1])/255.0, Double.parseDouble(fogColor[2])/255.0);

				color.reverseGammaCorrect(1.4, 1.65, 0);

				mShaderLoader.setFog(new LinearFog(2 * fogStart, 2 * fogEnd, 1, color));
			}
		}

		aProgressUpdater.update(5);

		mPlaneLump = BSPPlane.load(in, lumps[Lumps.PLANES.ordinal]); // 1
		mTexDataLump = BSPTexData.load(in, lumps[Lumps.TEXDATA.ordinal]); // 2
		mVertexLump = BSPVertex.load(in, lumps[Lumps.VERTEXES.ordinal]); // 3
		mVisData = BSPVisData.load(in, lumps[Lumps.VISIBILITY.ordinal]); // 4
		mNodeLump = BSPNode.load(in, lumps[Lumps.NODES.ordinal]); // 5
		mTexInfoLump = BSPTexInfo.load(in, lumps[Lumps.TEXINFO.ordinal]); // 6
		mFaceLump = BSPFace.load(in, lumps[Lumps.FACES.ordinal]); // 7
		mLightingLump = BSPLighting.load(in, lumps[Lumps.LIGHTING.ordinal]); // 8
		mLeafLump = BSPLeaf.load(in, lumps[Lumps.LEAFS.ordinal], version); // 10
		mEdgeLump = BSPEdge.load(in, lumps[Lumps.EDGES.ordinal]); // 12
		mSurfEdgeLump = BSPSurfEdge.load(in, lumps[Lumps.SURFEDGES.ordinal]); // 13
		mModelLump = BSPModel.load(in, lumps[Lumps.MODELS.ordinal]); // 14
		mWorldLights = BSPWorldLight.load(in, lumps[Lumps.WORLDLIGHTS.ordinal]); // 15
		mLeafFaceLump = BSPLeafFace.load(in, lumps[Lumps.LEAFFACES.ordinal]); // 16
		mDispInfoLump = BSPDispInfo.load(in, lumps[Lumps.DISPINFO.ordinal]); // 26
		//mOriginalFaceLump = BSPFace.load(in, lumps[Lumps.ORIGINALFACES.ordinal]); // 27
		//mDispLightmapAlphaLump = BSPDispLightmapAlpha.load(in, lumps[Lumps.DISP_LIGHTMAP_ALPHAS.ordinal]); // 32
		mDispVertLump = BSPDispVert.load(in, lumps[Lumps.DISP_VERTS.ordinal]); // 33
		//mDispLightmapPosLump = BSPDispLightmapSamplePos.load(in, lumps[Lumps.DISP_LIGHTMAP_SAMPLE_POSITIONS.ordinal]); // 34
		//mPrimitiveLump = BSPPrimitive.load(in, lumps[Lumps.PRIMITIVES.ordinal]); // 37
		//mPrimVertLump = BSPPrimVert.load(in, lumps[Lumps.PRIMVERTS.ordinal]); // 38
		//mPrimIndexLump = BSPPrimIndex.load(in, lumps[Lumps.PRIMINDICES.ordinal]); // 39
		mPakFileLump = BSPPakFile.load(in, lumps[Lumps.PAKFILE.ordinal]); // 40
		mTexDataStringLump = BSPTexDataStrings.load(in, lumps[Lumps.TEXDATA_STRING_DATA.ordinal]); // 43
		//mDispTriLump = BSPDispTri.load(in, lumps[Lumps.DISP_TRIS.ordinal]); // 48

		if (aProgressUpdater.isCanceled())
		{
			return;
		}

		aProgressUpdater.update(10, "Initializing word...");

		mSceneGraph = new SceneGraph();

		BranchGroup geometryPVSGroup = new BranchGroup();
		BranchGroup geometryGlobalGroup = new BranchGroup();
		Group modelGroup = new Group();

		for (int i = 0; i < mModelLump.length; i++)
		{
			BSPModel model = mModelLump[i];
			if (i == 0)
			{
				constructGroup(geometryPVSGroup, mNodeLump[model.mHeadNode]);
			}
			else
			{
				constructGroup(geometryGlobalGroup, mNodeLump[model.mHeadNode]);
			}
		}
		geometryPVSGroup.addChild(modelGroup);
		geometryPVSGroup.setPotentiallyVisibleSet(mVisData.mPVS);

		if (aProgressUpdater.isCanceled())
		{
			return;
		}

		aProgressUpdater.update(15);

		for (BSPFace face : mFaceLump)
		{
			if (face.mDispInfo != -1)
			{
				Geometry surface = constructFace(face, null);

				// look for a leaf that entirely encompases the displacement surface
				boolean b = false;
/*				for (BSPLeaf l : mLeafLump)
				{
					if (l.geometryGroup != null && surface.getBounds().intersect(l.mBounds))
					{
						BoundingBox bs = (BoundingBox)surface.getBounds();
						BoundingBox bb = (BoundingBox)l.mBounds;

						if (bs.getMin().x >= bb.getMin().x && bs.getMin().y >= bb.getMin().y && bs.getMin().z >= bb.getMin().z
						 && bs.getMax().x <= bb.getMax().x && bs.getMax().y <= bb.getMax().y && bs.getMax().z <= bb.getMax().z)
						{
							l.geometryGroup.addChild(surface);
							b = true;
							break;
						}
					}
				}*/

				if (!b) // a leaf was not found so we add the surface to a global list which is always rendered
				{
					GeometryGroup gg = new GeometryGroup(surface);
					gg.setFlags(Node.DISABLE_PVS);
					geometryPVSGroup.addChild(gg);
				}
			}
		}

		SkyBox skyBox = new SkyBox();
		String name = mEntityLump.getEntityByName("worldspawn").get(0).get("skyname");

		if (name.endsWith("_hdr"))
		{
			name = name.substring(0, name.length()-4);
		}

		skyBox.createDefaultMaterial(0, Texture.read(aResourceFinder.find("materials/skybox/" + name + "ft.vtf"), false));
		skyBox.createDefaultMaterial(1, Texture.read(aResourceFinder.find("materials/skybox/" + name + "bk.vtf"), false));
		skyBox.createDefaultMaterial(2, Texture.read(aResourceFinder.find("materials/skybox/" + name + "lf.vtf"), false));
		skyBox.createDefaultMaterial(3, Texture.read(aResourceFinder.find("materials/skybox/" + name + "rt.vtf"), false));
		skyBox.createDefaultMaterial(4, Texture.read(aResourceFinder.find("materials/skybox/" + name + "up.vtf"), false));
		skyBox.createDefaultMaterial(5, Texture.read(aResourceFinder.find("materials/skybox/" + name + "dn.vtf"), false));
		BranchGroup skyGroup = new BranchGroup(new GeometryGroup(skyBox));
		skyGroup.setRenderingCondition(new RenderOnceCondition());

		mDispInfoLump = null;
		mDispLightmapPosLump = null;
		mDispTriLump = null;
		mDispVertLump = null;
		mEdgeLump = null;
		mFaceLump = null;
		mOriginalFaceLump = null;
		mLeafFaceLump = null;
		mLightingLump = null;
		mModelLump = null;
		BSPPakFile mPakFileLump = null;
		mPlaneLump = null;
		mPrimIndexLump = null;
		mPrimitiveLump = null;
		mPrimVertLump = null;
		mSurfEdgeLump = null;
		mTexDataLump = null;
		mTexDataStringLump = null;
		mTexInfoLump = null;
		mVertexLump = null;
		mVisData = null;

		if (aProgressUpdater.isCanceled())
		{
			return;
		}

		aProgressUpdater.update(20, "Loading resources...");

		mGameLump = BSPGameLump.load(in, lumps[Lumps.GAMELUMP.ordinal], modelGroup, mResourceFinder, mShaderLoader, mLeafLump, aProgressUpdater); // 35

		mSceneGraph.addChild(geometryPVSGroup);
		mSceneGraph.addChild(geometryGlobalGroup);
		mSceneGraph.addChild(skyGroup);

		mShaderLoader = null;
	}


	public SceneGraph getSceneGraph()
	{
		return mSceneGraph;
	}


	public Vector getSkyCameraOrigin()
	{
		ArrayList<HashMap<String,String>> list = mEntityLump.getEntityByName("sky_camera");
		if (list.size() == 0)
		{
			return null;
		}
		String [] s = list.get(0).get("origin").split(" ");
		return new Vector(Double.parseDouble(s[0]), Double.parseDouble(s[2]), Double.parseDouble(s[1]));
	}


	public double getSkyCameraScale()
	{
		return Double.parseDouble(mEntityLump.getEntityByName("sky_camera").get(0).get("scale"));
	}


	private int findSurfPointStartIndex(Vector3f aStartPosition, Vector3f [] aCoords)
	{
		int minIndex = -1;
		double minDistance = Double.MAX_VALUE;

		for( int i = 0; i < 4; i++ )
		{
			double distance = aStartPosition.cloneVector().subtract(aCoords[i]).lengthSqr();
			if (distance < minDistance)
			{
				minDistance = distance;
				minIndex = i;
			}
		}

		return minIndex;
	}


	private void adjustSurfPointData(int aStartPointIndex, Vector3f [] aCoords)
	{
		if (aStartPointIndex == 0)
		{
			return;
		}

		Vector3f [] temp = aCoords.clone();

		for (int i = 0; i < 4; i++)
		{
			aCoords[i] = temp[(i+aStartPointIndex) % 4];
		}
	}


	private Geometry constructFace(BSPFace f, RenderingCondition aRenderingCondition) throws IOException
	{
		Geometry geometry;

		int lightmapWidth = f.mLightmapTextureSizeInLuxelsU + 1;
		int lightmapHeight = f.mLightmapTextureSizeInLuxelsV + 1;

		if (f.mDispInfo == -1)
		{
			VertexBuffer vertexBuffer = new VertexBuffer();

			int lastIndex = -1;
			int prevVertIndex = -1;

			for (int i = 0; i < f.mNumEdges; i++)
			{
				int index = mSurfEdgeLump[f.mFirstEdge+i].mIndex;
				int vertIndex;

				if (index < 0)
				{
					vertIndex = mEdgeLump[-index].mVertexIndices[1];
				}
				else
				{
					vertIndex = mEdgeLump[index].mVertexIndices[0];
				}

				vertexBuffer.addCoordinates(mVertexLump[vertIndex].mCoordinate);

				BSPTexInfo texInfo = mTexInfoLump[f.mTexInfo];
				int w = mTexDataLump[texInfo.mTexDataID].mWidth;
				int h = mTexDataLump[texInfo.mTexDataID].mHeight;
				Vector c = mVertexLump[vertIndex].mCoordinate;
				double u = c.dot(new Vector(texInfo.mTextureVecsTexelsPerWorldUnitsU)) + texInfo.mTextureOffsetU;
				double v = c.dot(new Vector(texInfo.mTextureVecsTexelsPerWorldUnitsV)) + texInfo.mTextureOffsetV;
				vertexBuffer.addTextureCoordinates(0, u / w, v / h);

				u = c.dot(new Vector(texInfo.mLightmapVecsLuxelsPerWorldUnitsU)) + texInfo.mLightmapOffsetU - f.mLightmapTextureMinsInLuxelsU;
				v = c.dot(new Vector(texInfo.mLightmapVecsLuxelsPerWorldUnitsV)) + texInfo.mLightmapOffsetV - f.mLightmapTextureMinsInLuxelsV;

				u /= lightmapWidth;
				v /= lightmapHeight;

				vertexBuffer.addTextureCoordinates(1, u+0.5/lightmapWidth, v+0.5/lightmapHeight);
				vertexBuffer.addColors(0, 1, 0, 1);

				prevVertIndex = vertIndex;
			}

			geometry = new TriangleFan(vertexBuffer);
		}
		else
		{
			if (f.mNumEdges != 4)
			{
				throw new RuntimeException("f.mNumEdges != 4");
			}
			
			Vector3f [] coords = new Vector3f[4];

			for (int i = 0; i < f.mNumEdges; i++)
			{
				int index = mSurfEdgeLump[f.mFirstEdge+i].mIndex;
				int vertIndex;

				if (index < 0)
				{
					vertIndex = mEdgeLump[-index].mVertexIndices[1];
				}
				else
				{
					vertIndex = mEdgeLump[index].mVertexIndices[0];
				}

				coords[i] = new Vector3f(mVertexLump[vertIndex].mCoordinate);
			}

			BSPDispInfo dispInfo = mDispInfoLump[f.mDispInfo];
			BSPTexInfo texInfo = mTexInfoLump[f.mTexInfo];

			int power = (1 << dispInfo.mPower);

			adjustSurfPointData(findSurfPointStartIndex(new Vector3f(dispInfo.mStartPosition), coords), coords);


			int n = (power+1)*(power+1);

			Vector3f [] dispDirections = new Vector3f[n];
			float [] dispAlphas = new float[n];
			float [] dispDistances = new float[n];

			System.arraycopy(mDispVertLump.mDirections, dispInfo.mDispVertStart, dispDirections, 0, n);
			System.arraycopy(mDispVertLump.mAlphas, dispInfo.mDispVertStart, dispAlphas, 0, n);
			System.arraycopy(mDispVertLump.mDistances, dispInfo.mDispVertStart, dispDistances, 0, n);

			geometry = new DisplacmentSurface(
				power, 
				coords, 
				dispDirections, 
				dispDistances, 
				dispAlphas, 
				texInfo.mTextureVecsTexelsPerWorldUnitsU, 
				texInfo.mTextureVecsTexelsPerWorldUnitsV, 
				f.mLightmapTextureSizeInLuxelsU, 
				f.mLightmapTextureSizeInLuxelsV, 
				texInfo.mTextureOffsetU, 
				texInfo.mTextureOffsetV, 
				mTexDataLump[texInfo.mTexDataID].mWidth, 
				mTexDataLump[texInfo.mTexDataID].mHeight
			);

/*
			Vector deltaY0 = new Vector(coords[1]).cloneVector().subtract(new Vector(coords[0])).divide(power);
			Vector deltaY1 = new Vector(coords[2]).cloneVector().subtract(new Vector(coords[3])).divide(power);
			Vector coord0 = new Vector(coords[0]).cloneVector();
			Vector coord1 = new Vector(coords[3]).cloneVector();

			VertexBuffer vertexBuffer = new VertexBuffer((power+1)*(power+1));
			IndexBuffer indexBuffer = new IndexBuffer(6 * power * power);

			for (int y = 0, j = dispInfo.mDispVertStart; y <= power; y++)
			{
				Vector deltaX = coord1.cloneVector().subtract(coord0).divide(power);
				Vector coord = coord0.cloneVector();

				for (int x = 0; x <= power; x++, j++)
				{
					Vector dispCoord = coord.cloneVector().add(new Vector(mDispVertLump.mDirections[j]).cloneVector().scale(mDispVertLump.mDistances[j]));
					vertexBuffer.addCoordinates(dispCoord);

					double u = coord.dot(new Vector(texInfo.mTextureVecsTexelsPerWorldUnitsU)) + texInfo.mTextureOffsetU;
					double v = coord.dot(new Vector(texInfo.mTextureVecsTexelsPerWorldUnitsV)) + texInfo.mTextureOffsetV;

					vertexBuffer.addTextureCoordinates(0, u / mTexDataLump[texInfo.mTexDataID].mWidth, v / mTexDataLump[texInfo.mTexDataID].mHeight);

					u = 0.5 + ((lightmapWidth-1) * x / (double)power);
					v = 0.5 + ((lightmapHeight-1) * y / (double)power);

					vertexBuffer.addTextureCoordinates(1, u / lightmapWidth, v / lightmapHeight);

					vertexBuffer.addColors4d(0, 1, 1, 1, mDispVertLump.mAlphas[j]);

					coord.add(deltaX);
				}

				coord0.add(deltaY0);
				coord1.add(deltaY1);
			}

			for (int y = 0; y < power; y++)
			{
				for (int x = 0; x < power; x++)
				{
					int ty = (y  )*(power+1) + x;
					int by = (y+1)*(power+1) + x;

					indexBuffer.addCoordinateIndices(          ty, by+1, ty+1, ty, by, by+1);
					indexBuffer.addColorIndices(            0, ty, by+1, ty+1, ty, by, by+1);
					indexBuffer.addTextureCoordinateIndices(0, ty, by+1, ty+1, ty, by, by+1);
					indexBuffer.addTextureCoordinateIndices(1, ty, by+1, ty+1, ty, by, by+1);
				}
			}

			geometry = new IndexedTriangleArray(vertexBuffer, indexBuffer);

			((IndexedTriangleArray)geometry).compact();
*/
		}

		if (f.mLightOffset == -1)
		{
			if (mWhiteTexture == null)
			{
				mWhiteTexture = new Texture(1,1,new int[]{0xff00ff00});
			}

			geometry.addTexture(mWhiteTexture);
		}
		else
		{
			geometry.addTexture(mLightingLump.getLightmap(f.mLightOffset, lightmapWidth, lightmapHeight));
		}

		String texName = mTexDataStringLump.mStrings[mTexDataLump[mTexInfoLump[f.mTexInfo].mTexDataID].mNameID].toLowerCase();

		Material appearance = mShaderLoader.loadMaterial(mResourceFinder, mPakFileLump, "materials/" + texName);

		geometry.setMaterial(appearance);
		geometry.setRenderingCondition(aRenderingCondition);
		
		if (f.mDispInfo == -1)
		{
			Texture tex = appearance.getShader(0).getTexture(0);
			
			if (tex != null)
			{
				Texture.Raster raster = tex.getRaster(tex.getNumMipLevels()-1);
				int color = raster.pixels[0];
				appearance.getShader(0).setConstantColor(new Color(color));
			}
		}
		else
		{
			appearance.getShader(0).setConstantColor(new Color(95/255.0,102/255.0,174/255.0));
		}

		return geometry;
	}


	private void constructGroup(Group aParentGroup, BSPNode aParent) throws IOException
	{
		Group group = new BSPGroup(mPlaneLump[aParent.mPlaneIndex].mPlane);
		group.setVisBounds(aParent.mBounds);

		if (aParent.mChildIndices[0] >= 0)
		{
			constructGroup(group, mNodeLump[aParent.mChildIndices[0]]);
		}
		else
		{
			constructLeaf(group, mLeafLump[-(aParent.mChildIndices[0]+1)]);
		}

		if (aParent.mChildIndices[1] >= 0)
		{
			constructGroup(group, mNodeLump[aParent.mChildIndices[1]]);
		}
		else
		{
			constructLeaf(group, mLeafLump[-(aParent.mChildIndices[1]+1)]);
		}

		if (group.getChildCount() > 0)
		{
			aParentGroup.addChild(group);
		}
	}


	private void constructLeaf(Group aParentGroup, BSPLeaf aLeaf) throws IOException
	{
		GeometryGroup geometryGroup = new GeometryGroup();
		geometryGroup.setVisBounds(aLeaf.mBounds);

		Group group = new Group();
		if (aLeaf.mCluster != -1)
		{
			geometryGroup.setFlags(Node.DISABLE_PVS);
			group.setIdentity(new NodeIdentity(aLeaf.mCluster));
		}
		group.setVisBounds(aLeaf.mBounds);

		for (int i = 0; i < aLeaf.mNumLeafFaces; i++)
		{
			int id = mLeafFaceLump.mIndices[aLeaf.mFirstLeafFace + i];
			
			RenderingCondition rc = mRenderingConditions.get(id);
			if (rc == null)
			{
				rc = new RenderOnceCondition();
				mRenderingConditions.put(id, rc);
			}

			BSPFace face = mFaceLump[id];

			if ((mTexInfoLump[face.mTexInfo].mFlags & SURFDRAW_NODRAW) != 0) continue;
			if ((mTexInfoLump[face.mTexInfo].mFlags & SURFDRAW_SKY) != 0) continue;
			if ((mTexInfoLump[face.mTexInfo].mFlags & SURFDRAW_ABOVEWATER) != 0) continue;

			geometryGroup.addChild(constructFace(face, rc));
		}

		if (geometryGroup.getChildCount() > 0)
		{
			aLeaf.geometryGroup = geometryGroup;
			group.addChild(geometryGroup);
		}

		aLeaf.parentGroup = group;

		aParentGroup.addChild(group);
	}
}