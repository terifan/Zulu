package org.terifan.zeus.io.halflife2;

import java.io.*;
import java.util.ArrayList;
import org.terifan.zeus.geometry.*;
import org.terifan.io.ByteBuffer;


/**
 * VTX is the extension for Source's proprietary mesh strip format. It stores 
 * hardware optimized material, skinning and triangle strip/fan information for 
 * each LOD of each mesh in the MDL. Currently it is found in .sw.vtx 
 * (Software), .dx80.vtx (DirectX 8.0) and .dx90.vtx (DirectX 9.0) flavours.
 */
public class VTXFile
{
	protected final static int MAX_NUM_BONES_PER_VERT = 3;

	private int mVertexCacheSize;
	private int mMaxBonesPerStrip;
	private int mMaxBonesPerTriangle;
	private int mMaxBonesPerVert;
	private int mMdlChecksum;
	private int mNumLODs;
	private int mMaterialReplacementListOffset;
	private int mNumBodyParts;
	private int mBodyPartOffset;
	private ArrayList<BodyPart> mBodyParts = new ArrayList<BodyPart>();
	private MaterialReplacementListHeader mMaterialReplacementListHeader;
	private File mFile;


	public VTXFile(File aFile, boolean aPrintLog) throws IOException
	{
		mFile = aFile;

		ByteBuffer in = ByteBuffer.createLittleEndian(aFile);

		int tmp;

		if ((tmp = in.getInt()) != 7)
		{
			throw new RuntimeException("Wrong version, expected 7, found: " + tmp);
		}

		mVertexCacheSize = in.getInt();
		mMaxBonesPerStrip = in.getUnsignedShort();
		mMaxBonesPerTriangle = in.getUnsignedShort();
		mMaxBonesPerVert = in.getInt();
		mMdlChecksum = in.getInt();
		mNumLODs = in.getInt();
		mMaterialReplacementListOffset = in.getInt();
		mNumBodyParts = in.getInt();
		mBodyPartOffset = in.getInt();

		if (aPrintLog)
		{
			System.out.println("mVertexCacheSize="+mVertexCacheSize);
			System.out.println("mMaxBonesPerStrip="+mMaxBonesPerStrip);
			System.out.println("mMaxBonesPerTriangle="+mMaxBonesPerTriangle);
			System.out.println("mMaxBonesPerVert="+mMaxBonesPerVert);
			System.out.println("mMdlChecksum="+mMdlChecksum);
			System.out.println("mNumLODs="+mNumLODs);
			System.out.println("mMaterialReplacementListOffset="+mMaterialReplacementListOffset);
			System.out.println("mNumBodyParts="+mNumBodyParts);
			System.out.println("mBodyPartOffset="+mBodyPartOffset);
		}

		in.position(mMaterialReplacementListOffset);

		mMaterialReplacementListHeader = new MaterialReplacementListHeader();
		mMaterialReplacementListHeader.mNumReplacements = in.getInt();
		mMaterialReplacementListHeader.mReplacementOffset = in.getInt();

		if (aPrintLog)
		{
			System.out.println("mMaterialReplacementListHeader.mNumReplacements="+mMaterialReplacementListHeader.mNumReplacements);
			System.out.println("mMaterialReplacementListHeader.mReplacementOffset="+mMaterialReplacementListHeader.mReplacementOffset);
		}

		for (int j = 0; j < mMaterialReplacementListHeader.mNumReplacements; j++)
		{
			MaterialReplacementHeader materialReplacementHeader = new MaterialReplacementHeader();
			materialReplacementHeader.mMaterialID = in.getShort();
			materialReplacementHeader.mReplacementMaterialNameOffset = in.getInt();
			mMaterialReplacementListHeader.mMaterialReplacements.add(materialReplacementHeader);
		}

		for (int j = 0; j < mNumBodyParts; j++)
		{
			in.position(mBodyPartOffset + j * 8);

			BodyPart bodyPart = new BodyPart();
			bodyPart.mNumModels = in.getInt();
			bodyPart.mModelOffset = in.getInt();
			mBodyParts.add(bodyPart);

			if (aPrintLog)
			{
				System.out.println("mBodyParts["+j+"].mNumModels="+bodyPart.mNumModels);
				System.out.println("mBodyParts["+j+"].mModelOffset="+bodyPart.mModelOffset);
			}

			in.position(mBodyPartOffset + bodyPart.mModelOffset);

			for (int i = 0; i < bodyPart.mNumModels; i++)
			{
				int offset1 = in.position();

				Model model = new Model();
				model.mNumLODs = in.getInt();
				model.mLodOffset = in.getInt();
				bodyPart.mModels.add(model);

				if (aPrintLog)
				{
					System.out.println("mBodyParts["+j+"].mModels["+i+"].mNumLODs="+model.mNumLODs);
					System.out.println("mBodyParts["+j+"].mModels["+i+"].mLodOffset="+model.mLodOffset);
				}

				in.position(offset1 + model.mLodOffset);

				for (int k = 0; k < model.mNumLODs; k++)
				{
					int offset2 = in.position();

					ModelLODHeader lodHeader = new ModelLODHeader();
					lodHeader.mNumMeshes = in.getInt();
					lodHeader.mMeshOffset = in.getInt();
					lodHeader.mSwitchPoint = in.getFloat();
					model.mModelLODs.add(lodHeader);

					if (aPrintLog)
					{
						System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mNumMeshes="+lodHeader.mNumMeshes);
						System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMeshOffset="+lodHeader.mMeshOffset);
						System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mSwitchPoint="+lodHeader.mSwitchPoint);
					}

					in.position(offset2 + lodHeader.mMeshOffset);

					for (int h = 0; h < lodHeader.mNumMeshes; h++)
					{
						int offset3 = in.position();

						MeshHeader meshHeader = new MeshHeader();
						meshHeader.mNumStripGroups = in.getInt();
						meshHeader.mStripGroupHeaderOffset = in.getInt();
						meshHeader.mFlags = in.getUnsignedByte();
						lodHeader.mMeshes.add(meshHeader);

						if (aPrintLog)
						{
							System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mNumStripGroups="+meshHeader.mNumStripGroups);
							System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroupHeaderOffset="+meshHeader.mStripGroupHeaderOffset);
							System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mFlags="+meshHeader.mFlags);
						}

						in.position(offset3 + meshHeader.mStripGroupHeaderOffset);

						for (int g = 0; g < meshHeader.mNumStripGroups; g++)
						{
							int offset4 = in.position();

							StripGroupHeader stripGroupHeader = new StripGroupHeader();
							stripGroupHeader.mNumVerts = in.getInt();
							stripGroupHeader.mVertOffset = in.getInt();
							stripGroupHeader.mNumIndices = in.getInt();
							stripGroupHeader.mIndexOffset = in.getInt();
							stripGroupHeader.mNumStrips = in.getInt();
							stripGroupHeader.mStripOffset = in.getInt();
							stripGroupHeader.mFlags = in.get();
							meshHeader.mStripGroups.add(stripGroupHeader);

							if (aPrintLog)
							{
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mNumVerts="+stripGroupHeader.mNumVerts);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mVertOffset="+stripGroupHeader.mVertOffset);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mNumIndices="+stripGroupHeader.mNumIndices);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mIndexOffset="+stripGroupHeader.mIndexOffset);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mNumStrips="+stripGroupHeader.mNumStrips);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStripOffset="+stripGroupHeader.mStripOffset);
								System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mFlags="+stripGroupHeader.mFlags);
							}

							in.position(offset4 + stripGroupHeader.mVertOffset);

							for (int m = 0; m < stripGroupHeader.mNumVerts; m++)
							{
								MeshVertex meshVertex = new MeshVertex();
								for (int index = 0; index < MAX_NUM_BONES_PER_VERT; index++)
								{
									meshVertex.mBoneWeightIndex[index] = in.getUnsignedByte();
								}
								meshVertex.mNumBones = in.get();
								meshVertex.mOrigMeshVertID = in.getShort();
								for (int index = 0; index < MAX_NUM_BONES_PER_VERT; index++)
								{
									meshVertex.mBoneID[index] = in.getUnsignedByte();
								}
								stripGroupHeader.mMeshVertices.add(meshVertex);

								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneWeightIndex[0]="+meshVertex.mBoneWeightIndex[0]);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneWeightIndex[1]="+meshVertex.mBoneWeightIndex[1]);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneWeightIndex[2]="+meshVertex.mBoneWeightIndex[2]);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mNumBones="+meshVertex.mNumBones);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mOrigMeshVertID="+meshVertex.mOrigMeshVertID);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneID[0]="+meshVertex.mBoneID[0]);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneID[1]="+meshVertex.mBoneID[1]);
								//System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mMeshVertices["+m+"].mBoneID[2]="+meshVertex.mBoneID[2]);
							}

							in.position(offset4 + stripGroupHeader.mIndexOffset);

							stripGroupHeader.mIndices = new int[stripGroupHeader.mNumIndices];

							for (int m = 0; m < stripGroupHeader.mNumIndices; m++)
							{
								stripGroupHeader.mIndices[m] = in.getUnsignedShort();
							}

							in.position(offset4 + stripGroupHeader.mStripOffset);

							for (int m = 0; m < stripGroupHeader.mNumStrips; m++)
							{
								int offset5 = in.position();

								StripHeader stripHeader = new StripHeader();
								stripHeader.mNumIndices = in.getInt();
								stripHeader.mIndexOffset = in.getInt();
								stripHeader.mNumVerts = in.getInt();
								stripHeader.mVertOffset = in.getInt();
								stripHeader.mNumBones = in.getShort();
								stripHeader.mFlags = in.get();
								stripHeader.mNumBoneStateChanges = in.getInt();
								stripHeader.mBoneStateChangeOffset = in.getInt();
								stripGroupHeader.mStrips.add(stripHeader);

								if (aPrintLog)
								{
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mNumIndices="+stripHeader.mNumIndices);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mIndexOffset="+stripHeader.mIndexOffset);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mNumVerts="+stripHeader.mNumVerts);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mVertOffset="+stripHeader.mVertOffset);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mNumBones="+stripHeader.mNumBones);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mFlags="+stripHeader.mFlags+" ("+(stripHeader.mFlags == StripHeader.STRIP_IS_TRILIST ? "triangle list" : stripHeader.mFlags == StripHeader.STRIP_IS_TRISTRIP ? "triangle strip" : "?") + ")");
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mNumBoneStateChanges="+stripHeader.mNumBoneStateChanges);
									System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mBoneStateChangeOffset="+stripHeader.mBoneStateChangeOffset);
								}

								in.position(offset5 + stripHeader.mBoneStateChangeOffset);

								for (int n = 0; n < stripHeader.mNumBoneStateChanges; n++)
								{
									BoneStateChangeHeader boneStateChangeHeader = new BoneStateChangeHeader();
									boneStateChangeHeader.mHardwareID = in.getInt();
									boneStateChangeHeader.mNewBoneID = in.getInt();
									stripHeader.mBoneStateChanges.add(boneStateChangeHeader);

									if (aPrintLog)
									{
										System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mBoneStateChange["+n+"].mHardwareID="+boneStateChangeHeader.mHardwareID);
										System.out.println("mBodyParts["+j+"].mModels["+i+"].mModelLOD["+k+"].mMesh["+h+"].mStripGroup["+g+"].mStrip["+m+"].mBoneStateChange["+n+"].mNewBoneID="+boneStateChangeHeader.mNewBoneID);
									}
								}

								in.position(offset5 + 27);
							}

							in.position(offset4 + 25);
						}

						in.position(offset3 + 9);
					}

					in.position(offset2 + 12);
				}

				in.position(offset1 + 8);
			}
		}
	}


	class BodyPart
	{
		int mNumModels;
		int mModelOffset;

		ArrayList<Model> mModels = new ArrayList<Model>();
	}


	class Model
	{
		int mNumLODs;
		int mLodOffset;

		ArrayList<ModelLODHeader> mModelLODs = new ArrayList<ModelLODHeader>();
	}


	class ModelLODHeader
	{
		int mNumMeshes;
		int mMeshOffset;
		double mSwitchPoint;

		ArrayList<MeshHeader> mMeshes = new ArrayList<MeshHeader>();
	}


	class MeshHeader
	{
		final static int MESH_IS_TEETH = 0x01;
		final static int MESH_IS_EYES = 0x02;

		int mNumStripGroups;
		int mStripGroupHeaderOffset;
		int mFlags;

		ArrayList<StripGroupHeader> mStripGroups = new ArrayList<StripGroupHeader>();
	}


	class StripGroupHeader
	{
		final static int STRIPGROUP_IS_FLEXED = 0x01;
		final static int STRIPGROUP_IS_HWSKINNED = 0x02;

		int mNumVerts;
		int mVertOffset;
		int mNumIndices;
		int mIndexOffset;
		int mNumStrips;
		int mStripOffset;
		int mFlags;

		ArrayList<StripHeader> mStrips = new ArrayList<StripHeader>();
		ArrayList<MeshVertex> mMeshVertices = new ArrayList<MeshVertex>();
		int [] mIndices;
	}


	class StripHeader
	{
		final static int STRIP_IS_TRILIST = 0x01;
		final static int STRIP_IS_TRISTRIP = 0x02;

		int mNumIndices;
		int mIndexOffset;
		int mNumVerts;
		int mVertOffset;
		int mNumBones;
		int mFlags;
		int mNumBoneStateChanges;
		int mBoneStateChangeOffset;

		ArrayList<BoneStateChangeHeader> mBoneStateChanges = new ArrayList<BoneStateChangeHeader>();
	}


	class MeshVertex
	{
		int [] mBoneWeightIndex = new int[MAX_NUM_BONES_PER_VERT];
		int mNumBones;
		int mOrigMeshVertID;
		int [] mBoneID = new int[MAX_NUM_BONES_PER_VERT];
	}
	

	class MaterialReplacementListHeader
	{
		int mNumReplacements;
		int mReplacementOffset;

		ArrayList<MaterialReplacementHeader> mMaterialReplacements = new ArrayList<MaterialReplacementHeader>();
	}


	class MaterialReplacementHeader
	{
		int mMaterialID;
		int mReplacementMaterialNameOffset;
	}


	class BoneStateChangeHeader
	{
		int mHardwareID;
		int mNewBoneID;
	}


	protected IndexBuffer getIndexBuffer(int aBodyPartIndex, int aModelIndex, int aMeshIndex, int aLod, int aVertexOffset)
	{
		BodyPart bodyPart = mBodyParts.get(aBodyPartIndex);
		Model model = bodyPart.mModels.get(aModelIndex);
		ModelLODHeader modelLod = model.mModelLODs.get(aLod);

		MeshHeader meshHeader = modelLod.mMeshes.get(aMeshIndex);

		int indexCount = 0;

		for (StripGroupHeader stripGroupHeader : meshHeader.mStripGroups)
		{
			indexCount += stripGroupHeader.mNumIndices;
		}

		IndexBuffer indexBuffer = new IndexBuffer(indexCount);

		for (StripGroupHeader stripGroupHeader : meshHeader.mStripGroups)
		{
			if (stripGroupHeader.mStrips.size() > 1) throw new RuntimeException("More than one strip found: " + stripGroupHeader.mStrips.size());
			if (stripGroupHeader.mStrips.get(0).mFlags != StripHeader.STRIP_IS_TRILIST) throw new RuntimeException("Strip not a tri-list");

			for (int i = 0, sz = stripGroupHeader.mNumIndices; i < sz; i+=3)
			{
				int a = aVertexOffset + stripGroupHeader.mMeshVertices.get(stripGroupHeader.mIndices[i+0]).mOrigMeshVertID;
				int b = aVertexOffset + stripGroupHeader.mMeshVertices.get(stripGroupHeader.mIndices[i+1]).mOrigMeshVertID;
				int c = aVertexOffset + stripGroupHeader.mMeshVertices.get(stripGroupHeader.mIndices[i+2]).mOrigMeshVertID;

				indexBuffer.addCoordinateIndex(a);
				indexBuffer.addCoordinateIndex(b);
				indexBuffer.addCoordinateIndex(c);
				indexBuffer.addNormalIndex(a);
				indexBuffer.addNormalIndex(b);
				indexBuffer.addNormalIndex(c);
				indexBuffer.addTextureCoordinateIndex(0, a);
				indexBuffer.addTextureCoordinateIndex(0, b);
				indexBuffer.addTextureCoordinateIndex(0, c);
				indexBuffer.addColorIndex(0, a);
				indexBuffer.addColorIndex(0, b);
				indexBuffer.addColorIndex(0, c);
			}
		}

		indexBuffer.compact();

		return indexBuffer;
	}


	protected BodyPart getBodyPart(int aIndex)
	{
		return mBodyParts.get(aIndex);
	}
}