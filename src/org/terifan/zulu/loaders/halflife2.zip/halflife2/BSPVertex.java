package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPVertex
{
	Vector mCoordinate;

	private BSPVertex(ByteBuffer aByteBuffer) throws IOException
	{
		mCoordinate = new Vector();
		mCoordinate.x = aByteBuffer.getFloat();
		mCoordinate.z = aByteBuffer.getFloat();
		mCoordinate.y = aByteBuffer.getFloat();
	}

	public static BSPVertex [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 12 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 12;

		System.out.println("Loading BSPVertex ("+count+" items)");

		BSPVertex [] elements = new BSPVertex[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPVertex(aByteBuffer);
		}

		return elements;
	}
}
