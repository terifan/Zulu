package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPDispTri
{
	public final static int DISPTRI_TAG_SURFACE = 1;
	public final static int DISPTRI_TAG_WALKABLE = 2;
	public final static int DISPTRI_TAG_BUILDABLE = 4;

	private static int mCounter;

	int mTags;

	private BSPDispTri(ByteBuffer aByteBuffer) throws IOException
	{
		mTags = aByteBuffer.getShort();
	}

	public static BSPDispTri [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 2 != 0)
		{
			throw new IOException("Uneven lump size: " + aLump.mLength);
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 2;

		System.out.println("Loading BSPDispTri ("+count+" items)");

		BSPDispTri [] elements = new BSPDispTri[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPDispTri(aByteBuffer);
		}

		return elements;
	}
}
