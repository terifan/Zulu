package org.terifan.zeus.io.halflife2;

import java.io.*;
import java.util.ArrayList;
import org.terifan.zeus.*;
import org.terifan.zeus.geometry.*;
import org.terifan.io.ByteBuffer;


/**
 * VVD is the extension for Source's proprietary model vertex data format. It 
 * stores position independent flat data for the bone weights, normals, 
 * vertices, tangents and texture coordinates used by the MDL.
 */
public class VVDFile
{
	protected final static int MAX_NUM_LODS = 8;

	private int mVersion;
	private int mMdlChecksum;
	private int mNumLODs;
	private int [] mNumLODVertexes = new int[MAX_NUM_LODS];
	private int mNumFixups;
	private int mFixupTableStart;
	private int mVertexDataStart;
	private int mTangentDataStart;
	private ArrayList<VertexFileFixup> mVertexFileFixups = new ArrayList<VertexFileFixup>();
	private VertexBuffer mVertexBuffer;
	private Tangent [][] mTangents = new Tangent[MAX_NUM_LODS][0];


	public VVDFile(File aFile, boolean aPrintLog) throws IOException
	{
		ByteBuffer in = ByteBuffer.createLittleEndian(aFile);

		int tmp;

		if (!in.getString(4,false,false).equals("IDSV"))
		{
			throw new RuntimeException("Bad header, expected 'IDSV' tag.");
		}
		if ((tmp = in.getInt()) != 4)
		{
			throw new RuntimeException("Wrong version, expected 7, found: " + tmp);
		}

		mMdlChecksum = in.getInt();
		mNumLODs = in.getInt();
		
		for (int i = 0; i < MAX_NUM_LODS; i++)
		{
			mNumLODVertexes[i] = in.getInt();
		}

		mNumFixups = in.getInt();
		mFixupTableStart = in.getInt();
		mVertexDataStart = in.getInt();
		mTangentDataStart = in.getInt();

		if (aPrintLog)
		{
			System.out.println("mMdlChecksum="+mMdlChecksum);
			System.out.println("mNumLODs="+mNumLODs);
			for (int i = 0; i < MAX_NUM_LODS; i++)
			{
				System.out.println("mNumLODVertexes["+i+"]="+mNumLODVertexes[i]);
			}
		}

		if (aPrintLog)
		{
			System.out.println("mNumFixups="+mNumFixups);
			System.out.println("mFixupTableStart="+mFixupTableStart);
			System.out.println("mVertexDataStart="+mVertexDataStart);
			System.out.println("mTangentDataStart="+mTangentDataStart);
		}

		for (int i = 0; i < mNumFixups; i++)
		{
			in.position(mFixupTableStart + i * 12);

			VertexFileFixup vertexFileFixup = new VertexFileFixup();
			vertexFileFixup.mLod = in.getInt();
			vertexFileFixup.mSourceVertexID = in.getInt();
			vertexFileFixup.mNumVertexes = in.getInt();
			mVertexFileFixups.add(vertexFileFixup);

			if (aPrintLog)
			{
				System.out.println("mVertexFileFixups["+i+"].mLod="+vertexFileFixup.mLod);
				System.out.println("mVertexFileFixups["+i+"].mSourceVertexID="+vertexFileFixup.mSourceVertexID);
				System.out.println("mVertexFileFixups["+i+"].mNumVertexes="+vertexFileFixup.mNumVertexes);
			}
		}


		if (mNumFixups == 0)
		{
			in.position(mVertexDataStart);
	
			mVertexBuffer = new VertexBuffer(mNumLODVertexes[0]);

			for (int i = 0, sz = mNumLODVertexes[0]; i < sz; i++)
			{
				double a = in.getFloat();
				double r = 0.5+0*in.getFloat();
				double g = 0.5+0*in.getFloat();
				double b = 0.5+0*in.getFloat();
				mVertexBuffer.addColors4d(0, r, g, b, a);
				mVertexBuffer.addCoordinates(getVector(in));
				mVertexBuffer.addNormals(getVector(in));
				mVertexBuffer.addTextureCoordinates(0, in.getFloat(), in.getFloat());
			}
		}
		else
		{
			int vertexCount = 0;
		
			for (int i = 0; i < mNumFixups; i++)
			{
				vertexCount += mVertexFileFixups.get(i).mNumVertexes;
			}

			mVertexBuffer = new VertexBuffer(vertexCount);

			for (int i = 0; i < mNumFixups; i++)
			{
				VertexFileFixup vertexFileFixup = mVertexFileFixups.get(i);

				in.position(mVertexDataStart + vertexFileFixup.mSourceVertexID * 48);
	
				for (int j = 0; j < vertexFileFixup.mNumVertexes; j++)
				{
					double a = in.getFloat();
					double r = 0.5+0*in.getFloat();
					double g = 0.5+0*in.getFloat();
					double b = 0.5+0*in.getFloat();
					mVertexBuffer.addColors4d(0, r, g, b, a);
					mVertexBuffer.addCoordinates(getVector(in));
					mVertexBuffer.addNormals(getVector(in));
					mVertexBuffer.addTextureCoordinates(0, in.getFloat(), in.getFloat());
				}
			}
		}
		
		mVertexBuffer.compact();

		in.position(mTangentDataStart);

		mTangents[0] = new Tangent[mNumLODVertexes[0]];
		for (int i = 0, sz = mNumLODVertexes[0]; i < sz; i++)
		{
			Tangent tangent = new Tangent();
			tangent.x = in.getFloat();
			tangent.y = in.getFloat();
			tangent.z = in.getFloat();
			tangent.w = in.getFloat();
			mTangents[0][i] = tangent;
		}
	}


	private Vector getVector(ByteBuffer aByteBuffer)
	{
		Vector v = new Vector();
		v.x = aByteBuffer.getFloat();
		v.z = aByteBuffer.getFloat();
		v.y = aByteBuffer.getFloat();
		return v;
	}


	class VertexFileFixup
	{
		int mLod; // used to skip culled root lod
		int mSourceVertexID; // absolute index from start of vertex/tangent blocks
		int mNumVertexes;
	}


	class Tangent
	{
		float x, y, z, w;
	}


	public VertexBuffer getVertexBuffer()
	{
		return mVertexBuffer;
	}
}