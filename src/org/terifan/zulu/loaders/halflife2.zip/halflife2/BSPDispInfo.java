package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPDispInfo
{
	// Max # of neighboring displacement touching a displacement's corner.
	private final static int MAX_DISP_CORNER_NEIGHBORS = 4;
	private final static int ALLOWEDVERTS_SIZE = 5;

	Vector mStartPosition;                     // start position used for orientation -- (added BSPVERSION 6)
	int mDispVertStart;                        // Index into LUMP_DISP_VERTS.
	int mDispTriStart;                         // Index into LUMP_DISP_TRIS.
    int mPower;                                // power - indicates size of map (2^power + 1)
    int mMinTess;                              // minimum tesselation allowed
    double mSmoothingAngle;                    // lighting smoothing angle
    int mContents;                             // surface contents
	int	mMapFace;                              // Which map face this displacement comes from.
	int	mLightmapAlphaStart;                   // Index into ddisplightmapalpha.
	                                           // The count is m_pParent->lightmapTextureSizeInLuxels[0]*m_pParent->lightmapTextureSizeInLuxels[1].

	int mLightmapSamplePositionStart;          // Index into LUMP_DISP_LIGHTMAP_SAMPLE_POSITIONS.

	DispEdgeNeighbor [] mEdgeNeighbors;        // Indexed by NEIGHBOREDGE_ defines.
	DispCornerNeighbors [] mCornerNeighbors;   // Indexed by CORNER_ defines.
	long [] mAllowedVerts;                     // This is built based on the layout and sizes of our neighbors
	                                           // and tells us which vertices are allowed to be active.

	private BSPDispInfo(ByteBuffer aByteBuffer) throws IOException
	{
		mStartPosition = new Vector();
		mEdgeNeighbors = new DispEdgeNeighbor[4];
		mCornerNeighbors = new DispCornerNeighbors[4];
		mAllowedVerts = new long[ALLOWEDVERTS_SIZE];

		mStartPosition.x = aByteBuffer.getFloat();
		mStartPosition.z = aByteBuffer.getFloat();
		mStartPosition.y = aByteBuffer.getFloat();

		mDispVertStart = aByteBuffer.getInt();
		mDispTriStart = aByteBuffer.getInt();
		
		mPower = aByteBuffer.getInt();
		mMinTess = aByteBuffer.getInt();
		mSmoothingAngle = aByteBuffer.getFloat();
		mContents = aByteBuffer.getInt();

		mMapFace = aByteBuffer.getUnsignedShort();

		int unknown = aByteBuffer.getUnsignedShort();

		mLightmapAlphaStart = aByteBuffer.getInt();
		mLightmapSamplePositionStart = aByteBuffer.getInt();

		mEdgeNeighbors[0] = new DispEdgeNeighbor(aByteBuffer);
		mEdgeNeighbors[1] = new DispEdgeNeighbor(aByteBuffer);
		mEdgeNeighbors[2] = new DispEdgeNeighbor(aByteBuffer);
		mEdgeNeighbors[3] = new DispEdgeNeighbor(aByteBuffer);

		mCornerNeighbors[0] = new DispCornerNeighbors(aByteBuffer);
		mCornerNeighbors[1] = new DispCornerNeighbors(aByteBuffer);
		mCornerNeighbors[2] = new DispCornerNeighbors(aByteBuffer);
		mCornerNeighbors[3] = new DispCornerNeighbors(aByteBuffer);

		for (int i = 0; i < ALLOWEDVERTS_SIZE; i++)
		{
			mAllowedVerts[i] = aByteBuffer.getLong(); // unsigned long !!
		}
	}

	public static BSPDispInfo [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 176 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 176;

		System.out.println("Loading BSPDispInfo ("+count+" items)");

		BSPDispInfo [] elements = new BSPDispInfo[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPDispInfo(aByteBuffer);
		}

		return elements;
	}


	private static int computeNumDispPowerVerts(int aPower)
	{
		return ((1 << aPower) + 1) * ((1 << aPower) + 1);
	}


	private static int computeNumDispPowerTris(int aPower)
	{
		return ((1 << aPower) * (1 << aPower) * 2);
	}


	static class DispEdgeNeighbor
	{
		DispSubEdgeNeighbor [] mSubNeighbors;

		DispEdgeNeighbor(ByteBuffer aByteBuffer) throws IOException
		{
			mSubNeighbors = new DispSubEdgeNeighbor[2];
			mSubNeighbors[0] = new DispSubEdgeNeighbor(aByteBuffer);
			mSubNeighbors[1] = new DispSubEdgeNeighbor(aByteBuffer);
		}
	}

	static class DispCornerNeighbors
	{
		int [] mNeighbors; // indices of neighbors.
		int mNumNeighbors;

		DispCornerNeighbors(ByteBuffer aByteBuffer) throws IOException
		{
			mNeighbors = new int[MAX_DISP_CORNER_NEIGHBORS];

			for (int i = 0; i < MAX_DISP_CORNER_NEIGHBORS; i++)
			{
				mNeighbors[i] = aByteBuffer.getUnsignedShort(); 
			}

			mNumNeighbors = aByteBuffer.getUnsignedShort();
		}
	}

	static class DispSubEdgeNeighbor
	{
		int mNeighbor;            // This indexes into ddispinfos (0xFFFF if there is no neighbor here.)
		int mNeighborOrientation; // (CCW) rotation of the neighbor wrt this displacement.
		int mSpan;                // Where the neighbor fits onto this side of our displacement.
		int mNeighborSpan;        // Where we fit onto our neighbor.

		DispSubEdgeNeighbor(ByteBuffer aByteBuffer) throws IOException
		{
			mNeighbor = aByteBuffer.getUnsignedShort();
			mNeighborOrientation = aByteBuffer.getUnsignedShort();
			mSpan = aByteBuffer.getUnsignedByte();
			mNeighborSpan = aByteBuffer.getUnsignedByte();
		}
	}
}