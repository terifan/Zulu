package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.io.ByteBuffer;


class BSPTexDataStrings
{
	String [] mStrings;

	private BSPTexDataStrings(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		byte [] buffer = new byte[aLump.mLength];
		aByteBuffer.position(aLump.mOffset);
		aByteBuffer.get(buffer);
		mStrings = new String(buffer).split("\0");
	}

	public static BSPTexDataStrings load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		System.out.println("Loading BSPTexDataStrings (1 items)");

		return new BSPTexDataStrings(aByteBuffer, aLump);
	}
}
