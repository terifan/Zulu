package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.zeus.scenegraph.*;
import org.terifan.io.ByteBuffer;


class BSPLeaf
{
	int mContents;        // OR of all brushes (not needed?)
	int mCluster;
	int mArea;
	int mFlags;
	BoundingBox mBounds;  // for frustum culling
	int	mFirstLeafFace;
	int	mNumLeafFaces;
	int	mFirstLeafBrush;
	int	mNumLeafBrushes;
	int mLeafWaterDataID; // -1 for not in water
	
	GeometryGroup geometryGroup;
	Group parentGroup;


	private BSPLeaf(ByteBuffer aByteBuffer, int aBSPVersion) throws IOException
	{
		mBounds = new BoundingBox();

		mContents = aByteBuffer.getInt();
		mCluster = aByteBuffer.getShort();
		mArea = aByteBuffer.getShort();
		mFlags = mArea >> 9;
		mArea &= 511;
		Vector v = new Vector();
		v.x = aByteBuffer.getShort();
		v.z = aByteBuffer.getShort();
		v.y = aByteBuffer.getShort();
		mBounds.merge(v);
		v.x = aByteBuffer.getShort();
		v.z = aByteBuffer.getShort();
		v.y = aByteBuffer.getShort();
		mBounds.merge(v);
		mFirstLeafFace = aByteBuffer.getUnsignedShort();
		mNumLeafFaces = aByteBuffer.getUnsignedShort();
		mFirstLeafBrush = aByteBuffer.getUnsignedShort();
		mNumLeafBrushes = aByteBuffer.getUnsignedShort();
		mLeafWaterDataID = aByteBuffer.getShort();

		if (aBSPVersion == 19)
		{
			aByteBuffer.skip(24);
		}

		aByteBuffer.skip(2); // padding

		//System.out.println(mContents+"\t"+mCluster+"\t"+mArea+"\t"+mFlags+"\t"+mFirstLeafFace+"\t"+mNumLeafFaces+"\t"+mFirstLeafBrush+"\t"+mNumLeafBrushes+"\t"+mLeafWaterDataID);
	}


	public static BSPLeaf [] load(ByteBuffer aByteBuffer, BSPLump aLump, int aBSPVersion) throws IOException
	{
		if (aLump.mLength % (aBSPVersion == 19 ? 56 : 32) != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / (aBSPVersion == 19 ? 56 : 32);

		System.out.println("Loading BSPLeaf ("+count+" items)");

		BSPLeaf [] elements = new BSPLeaf[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPLeaf(aByteBuffer, aBSPVersion);
		}

		return elements;
	}
}
