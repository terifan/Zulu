package org.terifan.zeus.io.halflife2;

import java.io.*;
import java.util.HashMap;
import org.terifan.zeus.*;
import org.terifan.zeus.util.*;
import org.terifan.util.script.*;


public class ShaderLoader
{
	private HashMap<String,Material> mMaterials = new HashMap<String,Material>();
	private HashMap<String,Texture> mTextures = new HashMap<String,Texture>();
	private HashMap<String,String> mScripts = new HashMap<String,String>();
	private Fog mFog;


	public Material loadMaterial(ResourceFinder aResourceFinder, String aName) throws IOException
	{
		return loadMaterial(aResourceFinder, null, aName);
	}


	public Material loadMaterial(ResourceFinder aResourceFinder, BSPPakFile aPakFile, String aName) throws IOException
	{
		Material material = null;
		String script = null;

		if (mMaterials.containsKey(aName))
		{
			material = mMaterials.get(aName);
		}
		else if (aPakFile != null && aPakFile.mScripts.containsKey(aName + ".vmt") || aResourceFinder.find(aName + ".vmt") != null)
		{
			material = buildScriptMaterial(aResourceFinder, aPakFile, aName);
		}
		else
		{
			Shader shader = new Shader();
			shader.addTexture(getTexture(aResourceFinder, aPakFile, aName));
			shader.setIgnoreVertexColors(true);
			if (BSPLoader.FILTER_TEXTURES) shader.setTextureFilter(TextureFilter.BILINEAR);
			material = new Material(shader);
		}

		mMaterials.put(aName, material);

		Texture tex = material.getShader(0).getTexture(0);
		if (tex != null)
		{
			Texture.Raster raster = tex.getRaster(tex.getNumMipLevels()-1);
			int color = raster.pixels[0];
			material.getShader(0).setConstantColor(new Color(color));
		}

		return material;
	}


	public void setFog(Fog aFog)
	{
		mFog = aFog;
	}


	private Material buildScriptMaterial(ResourceFinder aResourceFinder, BSPPakFile aPakFile, String aMaterialName) throws IOException
	{
		HashMap<String,Object> variables = new HashMap<String,Object>();

		boolean filter = BSPLoader.FILTER_TEXTURES;

		String baseShader = loadScript(aResourceFinder, aPakFile, variables, getScript(aResourceFinder, aPakFile, aMaterialName).replace('\\','/'));

		Material material;

		if (baseShader.equalsIgnoreCase("LightmappedGeneric"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture")));
			shader1.setIgnoreVertexColors(true);
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			Shader shader2 = new Shader();
			shader2.setBlendFunctions(BlendFunc.DST_COLOR, BlendFunc.ZERO);
			shader2.setTextureCoordinateSetIndex(1);
			shader2.setTextureSource(TextureSource.GEOMETRY);
			shader2.setMipMapEnabled(false);
			shader2.setIgnoreVertexColors(true);
			if (filter) shader2.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1, shader2);
		}
		else if (baseShader.equalsIgnoreCase("WorldVertexTransition"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture")));
			shader1.setIgnoreVertexColors(true);
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			Shader shader2 = new Shader();
			shader2.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture2")));
			shader2.setBlendFunctions(BlendFunc.VERTEX_ALPHA, BlendFunc.INV_VERTEX_ALPHA);
			if (filter) shader2.setTextureFilter(TextureFilter.BILINEAR);

			Shader shader3 = new Shader();
			shader3.setBlendFunctions(BlendFunc.DST_COLOR, BlendFunc.ZERO);
			shader3.setTextureCoordinateSetIndex(1);
			shader3.setTextureSource(TextureSource.GEOMETRY);
			shader3.setMipMapEnabled(false);
			shader3.setIgnoreVertexColors(true);
			if (filter) shader3.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1, shader2, shader3);
		}
		else if (baseShader.equalsIgnoreCase("WorldTwoTextureBlend"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture")));
			shader1.setIgnoreVertexColors(true);
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			Shader shader2 = new Shader();
			shader2.setBlendFunctions(BlendFunc.DST_COLOR, BlendFunc.ZERO);
			shader2.setTextureCoordinateSetIndex(1);
			shader2.setTextureSource(TextureSource.GEOMETRY);
			shader2.setMipMapEnabled(false);
			shader2.setIgnoreVertexColors(true);
			if (filter) shader2.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1, shader2);
		}
		else if (baseShader.equalsIgnoreCase("Water"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, "dev/water"));
			shader1.setIgnoreVertexColors(true);
			shader1.setBlendFunctions(BlendFunc.CONST_ALPHA, BlendFunc.INV_CONST_ALPHA);
			shader1.setConstantAlpha(0.3);
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1);
			material.setGammaCorrectionEnabled(false);
			material.setDepthWriteFunc(DepthWriteFunc.NEVER);
			material.setDepthSort(true);
		}
		else if (baseShader.equalsIgnoreCase("vertexlitgeneric"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture")));
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1);
		}
		else if (baseShader.equalsIgnoreCase("unlitgeneric"))
		{
			Shader shader1 = new Shader();
			shader1.addTexture(getTexture(aResourceFinder, aPakFile, ""+variables.get("$basetexture")));
			shader1.setIgnoreVertexColors(true);
			if (filter) shader1.setTextureFilter(TextureFilter.BILINEAR);

			material = new Material(shader1);
		}
		else
		{
			System.out.println("Unsupported base shader: " + baseShader);

			Shader shader = new Shader();
			shader.setIgnoreVertexColors(true);
			shader.addTexture(Texture.read(new File(org.terifan.zeus.View.class.getResource("resources/brick.jpg").getPath()).getAbsolutePath(), true));
			
			material = new Material(shader);
		}
		
//		material.setFog(mFog);
		
/*
		"$debug",
		"$no_fullbright",
		"$no_draw",
		"$use_in_fillrate_mode",

		"$vertexcolor",
		"$vertexalpha",
		"$selfillum",
		"$additive",
		"$alphatest",
		"$multipass",
		"$znearer",
		"$model",
		"$flat",
		"$envmapsphere",
		"$noalphamod",
		"$envmapcameraspace",
		"$nooverbright",
		"$basealphaenvmapmask",
		"$translucent",
		"$normalmapalphaenvmapmask",
		"$softwareskin",
		"$opaquetexture",
		"$envmapmode",
*/

		if (variables.containsKey("$nofog") && variables.get("$nofog").toString().equals("1"))
		{
			material.setFog(null);
		}
		if (variables.containsKey("$alpha") && variables.get("$alpha").toString().equals("1"))
		{
			material.getShader(0).setBlendFunctions(BlendFunc.SRC_ALPHA, BlendFunc.INV_SRC_ALPHA);
			material.setDepthWriteFunc(DepthWriteFunc.GREATER);
			material.setDepthWriteValue(0.5);
			material.setDepthSort(true);
		}
		if (variables.containsKey("$translucent") && variables.get("$translucent").toString().equals("1"))
		{
			material.getShader(0).setBlendFunctions(BlendFunc.SRC_ALPHA, BlendFunc.INV_SRC_ALPHA);
			material.setDepthWriteFunc(DepthWriteFunc.GREATER);
			material.setDepthWriteValue(0.5);
			material.setDepthSort(true);
		}
		if (variables.containsKey("$additive") && variables.get("$additive").toString().equals("1"))
		{
			material.getShader(0).setBlendFunctions(BlendFunc.ONE, BlendFunc.ONE);
			material.setDepthWriteFunc(DepthWriteFunc.NEVER);
			material.setDepthSort(true);
		}
		if (variables.containsKey("$nocull") && variables.get("$nocull").toString().equals("1"))
		{
			material.setCullFace(CullFace.NONE);
		}
		if (variables.containsKey("$ignorez") && variables.get("$ignorez").toString().equals("1"))
		{
//			material.setDepthTestFunc(DepthTestFunc.NONE);
//			material.setDepthWriteFunc(DepthWriteFunc.NEVER);
		}
		if (variables.containsKey("$decal") && variables.get("$decal").toString().equals("1"))
		{
			material.setDepthTestFunc(DepthTestFunc.NONE);
			material.setDepthWriteFunc(DepthWriteFunc.NEVER);
		}
		if (variables.containsKey("$znearer") && variables.get("$decal").toString().equals("1"))
		{
			material.setDepthTestFunc(DepthTestFunc.LESS);
		}
		if (variables.containsKey("$model") && variables.get("$model").toString().equals("1"))
		{
			material.getShader(0).setIgnoreVertexColors(false);
		}
		if (variables.containsKey("$alphatest") && variables.get("$alphatest").toString().equals("1"))
		{
			material.getShader(0).setAlphaTestFunc(AlphaTestFunc.GREATER);
			material.getShader(0).setAlphaTestValue(0.5);
		}

		return material;
	}


	private String loadScript(ResourceFinder aResourceFinder, BSPPakFile aPakFile, HashMap<String,Object> aVariables, String aScript) throws IOException
	{
		Scanner scanner = new Scanner(new JavaLanguage(), new StringReader(aScript));

		String baseShader = scanner.next().toString();

		while (scanner.hasNext())
		{
			LanguageElement o = scanner.next();

			if (o instanceof Literal)
			{
				String s = o.toString();

				if (s.startsWith("$") || s.startsWith("%"))
				{
					o = scanner.next();

					Object v = ((Literal)o).getValue();
					if (v instanceof String || v instanceof Number)
					{
						aVariables.put(s.toLowerCase(), v);
					}
					else
					{
						// ignore
					}
				}
				else if (s.equalsIgnoreCase("include"))
				{
					s = getScript(aResourceFinder, aPakFile, scanner.next().toString());

					if (s != null)
					{
						s = loadScript(aResourceFinder, aPakFile, aVariables, s.replace('\\','/'));
						
						if (baseShader.equals("patch"))
						{
							baseShader = s;
						}
					}
				}
				else
				{
					if (scanner.peek() instanceof Operator)
					{
						// ignore
					}
				}
			}
		}

		return baseShader;
	}


	private Texture getTexture(ResourceFinder aResourceFinder, BSPPakFile aPakFile, String aName) throws IOException
	{
		Texture tex;

		if (!aName.toLowerCase().endsWith(".vtf"))
		{
			aName += ".vtf";
		}

		if (aPakFile != null && aPakFile.mTextures.containsKey(aName))
		{
			//System.out.println("Loading PAK texure: " + aName);
			tex = aPakFile.mTextures.get(aName);
		}
		else if (mTextures.containsKey(aName))
		{
			tex = mTextures.get(aName);
		}
		else if (aResourceFinder.find(aName) != null)
		{
			try
			{
				//System.out.println("Loading FILE texure: " + aName);
				tex = Texture.read(aResourceFinder.find(aName), true);
			}
			catch (IOException e)
			{
				System.out.println("Texture missing: " + aName);
				tex = Texture.read(View.class.getResource("resources/brick.jpg"), false);
			}
		}
		else
		{
			if (aName.toLowerCase().startsWith("materials/"))
			{
				System.out.println("Texture missing: " + aName);
				tex = Texture.read(View.class.getResource("resources/brick.jpg"), false);
			}
			else
			{
				tex = getTexture(aResourceFinder, aPakFile, "materials/" + aName);
			}
		}

		mTextures.put(aName, tex);

		return tex;
	}


	private String getScript(ResourceFinder aResourceFinder, BSPPakFile aPakFile, String aScriptName) throws IOException
	{
		if (!aScriptName.toLowerCase().endsWith(".vmt"))
		{
			aScriptName += ".vmt";
		}
	
		if (aPakFile != null && aPakFile.mScripts.containsKey(aScriptName))
		{
			return aPakFile.mScripts.get(aScriptName);
		}
		else if (mScripts.containsKey(aScriptName))
		{
			return mScripts.get(aScriptName);
		}
		else if (aResourceFinder.find(aScriptName) != null)
		{
			File file = aResourceFinder.find(aScriptName);
			byte [] buf = new byte[(int)file.length()];
			FileInputStream in = new FileInputStream(file);
			in.read(buf);
			in.close();

			String s = new String(buf);
			mScripts.put(aScriptName, s);
			return s;
		}
		else if (!aScriptName.toLowerCase().startsWith("materials/"))
		{
			return getScript(aResourceFinder, aPakFile, "materials/" + aScriptName);
		}

		System.out.println("Script not found: " + aScriptName);

		return null;
	}

/*


	if (flags & MATERIAL_VAR_IGNOREZ)
	{
		s_pShaderShadow->EnableDepthTest( false );
		s_pShaderShadow->EnableDepthWrites( false );
	}

	if (flags & MATERIAL_VAR_DECAL)
	{
		s_pShaderShadow->EnablePolyOffset( true );
		s_pShaderShadow->EnableDepthWrites( false );
	}

	if ((flags & MATERIAL_VAR_MODEL) && (g_pHardwareConfig->MaxBlendMatrices() > 1))
	{
		s_pShaderShadow->EnableVertexBlend( true );
	}

	if (flags & MATERIAL_VAR_NOCULL)
	{
		s_pShaderShadow->EnableCulling( false );
	}

	if (flags & MATERIAL_VAR_ZNEARER)
	{
		s_pShaderShadow->DepthFunc( SHADER_DEPTHFUNC_NEARER );
	}


*/
}