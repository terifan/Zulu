package org.terifan.zeus.io.halflife2;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;
import org.terifan.zeus.scenegraph.*;
import org.terifan.zeus.util.*;


class BSPGameLump
{
	private ArrayList<GameLump> mGameLumps = new ArrayList<GameLump>();


	public static BSPGameLump load(ByteBuffer aByteBuffer, BSPLump aLump, Group aGroup, ResourceFinder aResourceFinder, ShaderLoader aShaderLoader, BSPLeaf [] aLeafLump, LoadProgressUpdater aProgressUpdater) throws IOException
	{
		return new BSPGameLump(aByteBuffer, aLump, aGroup, aResourceFinder, aShaderLoader, aLeafLump, aProgressUpdater);
	}


	private BSPGameLump(ByteBuffer aByteBuffer, BSPLump aLump, Group aGroup, ResourceFinder aResourceFinder, ShaderLoader aShaderLoader, BSPLeaf [] aLeafLump, LoadProgressUpdater aProgressUpdater) throws IOException
	{
		aByteBuffer.position(aLump.mOffset);

		int numLumps = aByteBuffer.getInt();

		System.out.println("Loading BSPGameLump");

		for (int i = 0; i < numLumps; i++)
		{
			GameLump gameLump = new GameLump();
			gameLump.id = aByteBuffer.getString(4,false,false);
			gameLump.flags = aByteBuffer.getUnsignedShort();
			gameLump.version = aByteBuffer.getUnsignedShort();
			gameLump.fileofs = aByteBuffer.getInt();
			gameLump.filelen = aByteBuffer.getInt();
			mGameLumps.add(gameLump);
		}


		String [][] staticPropDict = new String[numLumps][];
		int [][] staticPropLeafLump = new int[numLumps][];
		StaticPropLump [][] staticPropLumps = new StaticPropLump[numLumps][];
		int loadCount = 0;

		for (int i = 0; i < numLumps; i++)
		{
			GameLump lump = mGameLumps.get(i);

			if (lump.id.equals("prps"))
			{
				aByteBuffer.position(lump.fileofs);

				staticPropDict[i] = new String[aByteBuffer.getInt()];

				for (int j = 0; j < staticPropDict[i].length; j++)
				{
					staticPropDict[i][j] = aByteBuffer.getString(128,true,true);
				}

				staticPropLeafLump[i] = new int[aByteBuffer.getInt()];
				for (int j = 0; j < staticPropLeafLump[i].length; j++)
				{
					staticPropLeafLump[i][j] = aByteBuffer.getUnsignedShort();
				}
		
				staticPropLumps[i] = new StaticPropLump[aByteBuffer.getInt()];

				for (int j = 0; j < staticPropLumps[i].length; j++)
				{
					staticPropLumps[i][j] = new StaticPropLump();
		
					staticPropLumps[i][j].mOrigin = readVector(aByteBuffer);
					staticPropLumps[i][j].mAngles = new QAngle(readVector(aByteBuffer));
					staticPropLumps[i][j].mPropType = aByteBuffer.getUnsignedShort();
					staticPropLumps[i][j].mFirstLeaf = aByteBuffer.getUnsignedShort();
					staticPropLumps[i][j].mLeafCount = aByteBuffer.getUnsignedShort();
					staticPropLumps[i][j].mSolid = aByteBuffer.getUnsignedByte();
					staticPropLumps[i][j].mFlags = aByteBuffer.getUnsignedByte();
					staticPropLumps[i][j].mSkin = aByteBuffer.getInt();
					staticPropLumps[i][j].mFadeMinDist = aByteBuffer.getFloat();
					staticPropLumps[i][j].mFadeMaxDist = aByteBuffer.getFloat();
					staticPropLumps[i][j].mLightingOrigin = readVector(aByteBuffer);
					staticPropLumps[i][j].mForcedFadeScale = aByteBuffer.getFloat();

					loadCount++;
				}
			}
		}


		HashMap<String,Group> cache = new HashMap<String,Group>();

		for (int i = 0, loadIndex = 0; i < numLumps; i++)
		{
			GameLump lump = mGameLumps.get(i);

			if (lump.id.equals("prps"))
			{
				for (int j = 0; j < staticPropLumps[i].length; j++, loadIndex++)
				{
					aProgressUpdater.update(20+(int)Math.round(75*loadIndex/(double)loadCount));

					if (aProgressUpdater.isCanceled())
					{
						return;
					}

					String name = staticPropDict[i][staticPropLumps[i][j].mPropType];
					if (name.startsWith("./"))
					{
						name = name.substring(2);
					}

					Transform3D tr = new Transform3D();
					tr.translate(staticPropLumps[i][j].mOrigin);
					tr.rotate(staticPropLumps[i][j].mAngles.toVector());

					RenderingCondition renderingCondition = new RenderOnceCondition();

					for (int k = 0; k < staticPropLumps[i][j].mLeafCount; k++)
					{
						Group model;

						if (cache.containsKey(name))
						{
							model = cloneModel(cache.get(name));
						}
						else
						{
							System.out.println("   Loading model: " + name);
							model = loadModel(aResourceFinder, name, "sw", aShaderLoader);
							cache.put(name, model);
						}

						model.setRenderingCondition(renderingCondition);
						TransformGroup transformGroup = new TransformGroup(tr, model);
						transformGroup.setFlags(Node.DISABLE_PVS);
						Group group = aLeafLump[staticPropLeafLump[i][staticPropLumps[i][j].mFirstLeaf+k]].parentGroup;
						group.addChild(transformGroup);
					}
				}
			}
		}



	}


	private Group loadModel(ResourceFinder aResourceFinder, String aModelName, String aMeshVersion, ShaderLoader aShaderLoader) throws IOException
	{
		String name = aModelName.substring(0, aModelName.lastIndexOf("."));
		String key = name.toLowerCase();

		MDLFile mdl = new MDLFile(aResourceFinder.find(name + ".mdl"), false);
		VTXFile vtx = new VTXFile(aResourceFinder.find(name + "."+aMeshVersion+".vtx"), false);
		VVDFile vvd = new VVDFile(aResourceFinder.find(name + ".vvd"), false);

		return mdl.buildModel(aResourceFinder, aShaderLoader, vtx, vvd);
	}


	private Group cloneModel(Group aModel)
	{
		Group newModel = new Group();
		
		cloneNode(aModel, newModel);

		return newModel;
	}


	private void cloneNode(Group aSource, Group aDestination)
	{
		for (int i = 0; i < aSource.getChildCount(); i++)
		{
			Node node = aSource.getChild(i);

			if (node instanceof SwitchGroup)
			{
				SwitchGroup switchGroup = new SwitchGroup();
				aDestination.addChild(switchGroup);
				cloneNode((SwitchGroup)node, switchGroup);
				switchGroup.setActiveChild(((SwitchGroup)node).getActiveChild());
			}
			else if (node instanceof GeometryGroup)
			{
				GeometryGroup group = new GeometryGroup();
				aDestination.addChild(group);
				GeometryGroup source = (GeometryGroup)node;
				for (int j = 0; j < source.getChildCount(); j++)
				{
					group.addChild(source.getChild(j));
				}
			}
			else if (node instanceof Group)
			{
				Group group = new Group();
				aDestination.addChild(group);
				cloneNode((Group)node, group);
			}
			else
			{
				throw new RuntimeException(""+node.getClass());
			}
		}
	}


	private Vector readVector(ByteBuffer aByteBuffer) throws IOException
	{
		Vector v = new Vector();
		v.x = aByteBuffer.getFloat();
		v.z = aByteBuffer.getFloat();
		v.y = aByteBuffer.getFloat();
		return v;
	}


	class GameLump
	{
		String id;
		int flags;
		int version;
		int fileofs;
		int filelen;
	}


	class StaticPropLump
	{
		Vector mOrigin;
		QAngle mAngles;
		int mPropType;
		int mFirstLeaf;
		int mLeafCount;
		int mSolid;
		int mFlags;
		int mSkin;
		double mFadeMinDist;
		double mFadeMaxDist;
		Vector mLightingOrigin;
		double mForcedFadeScale;
	}


	class QAngle
	{
		double pitch, roll, yaw;

		QAngle(Vector v)
		{
			pitch = v.x;
			roll = v.y;
			yaw = v.z;
		}

		public Vector toVector()
		{
			return new Vector(roll/360.0, 1-yaw/360.0, 1-pitch/360.0);
/*
			//return new Vector(1-roll/360.0, 1-yaw/360.0, 1-pitch/360.0);

			//return new Vector(pitch/360.0, yaw/360.0, roll/360.0);

//			if (pitch > 180) pitch -= 360;
//			if (roll > 180) roll -= 360;
//			if (yaw > 180) yaw -= 360;

			double p = pitch/360.0;
			double r = roll/360.0;
			double y = yaw/360.0;

			return new Vector(p, r, y);
*/
		}

		@Override
		public String toString()
		{
			return "[pitch="+pitch+", roll="+roll+", yaw="+yaw+"]";
		}
	}	
}