package org.terifan.zeus.io.halflife2;

import java.io.IOException;
import org.terifan.zeus.*;
import org.terifan.io.ByteBuffer;


class BSPTexInfo
{
	Vector3f mTextureVecsTexelsPerWorldUnitsU;
	Vector3f mTextureVecsTexelsPerWorldUnitsV;
	float mTextureOffsetU;
	float mTextureOffsetV;
	Vector3f mLightmapVecsLuxelsPerWorldUnitsU;
	Vector3f mLightmapVecsLuxelsPerWorldUnitsV;
	float mLightmapOffsetU;
	float mLightmapOffsetV;
	int mFlags;      // miptex flags + overrides
	int mTexDataID;  // Pointer to texture name, size, etc.

	private BSPTexInfo(ByteBuffer aByteBuffer) throws IOException
	{
		mTextureVecsTexelsPerWorldUnitsU = new Vector3f();
		mTextureVecsTexelsPerWorldUnitsV = new Vector3f();
		mLightmapVecsLuxelsPerWorldUnitsU = new Vector3f();
		mLightmapVecsLuxelsPerWorldUnitsV = new Vector3f();

		mTextureVecsTexelsPerWorldUnitsU.x = aByteBuffer.getFloat();
		mTextureVecsTexelsPerWorldUnitsU.z = aByteBuffer.getFloat();
		mTextureVecsTexelsPerWorldUnitsU.y = aByteBuffer.getFloat();
		mTextureOffsetU = aByteBuffer.getFloat();
		mTextureVecsTexelsPerWorldUnitsV.x = aByteBuffer.getFloat();
		mTextureVecsTexelsPerWorldUnitsV.z = aByteBuffer.getFloat();
		mTextureVecsTexelsPerWorldUnitsV.y = aByteBuffer.getFloat();
		mTextureOffsetV = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsU.x = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsU.z = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsU.y = aByteBuffer.getFloat();
		mLightmapOffsetU = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsV.x = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsV.z = aByteBuffer.getFloat();
		mLightmapVecsLuxelsPerWorldUnitsV.y = aByteBuffer.getFloat();
		mLightmapOffsetV = aByteBuffer.getFloat();
		mFlags = aByteBuffer.getInt();
		mTexDataID = aByteBuffer.getInt();
	}

	public static BSPTexInfo [] load(ByteBuffer aByteBuffer, BSPLump aLump) throws IOException
	{
		if (aLump.mLength % 72 != 0)
		{
			throw new IOException("Uneven lump size.");
		}

		aByteBuffer.position(aLump.mOffset);
		int count = aLump.mLength / 72;

		System.out.println("Loading BSPTexInfo ("+count+" items)");

		BSPTexInfo [] elements = new BSPTexInfo[count];

		for (int index = 0; index < count; index++)
		{
			elements[index] = new BSPTexInfo(aByteBuffer);
		}

		return elements;
	}
}
